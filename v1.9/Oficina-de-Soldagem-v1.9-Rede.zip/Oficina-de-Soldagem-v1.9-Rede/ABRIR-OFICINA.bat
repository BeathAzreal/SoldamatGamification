@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
if not exist "%~dp0runtime\node.exe" (
 echo Extraia o pacote completo antes de abrir o jogo. A pasta runtime deve ficar junto do lancador.
 pause
 exit /b 1
)
set ABRIR_NAVEGADOR=1
if "%SEM_ABRIR_NAVEGADOR%"=="1" set ABRIR_NAVEGADOR=0
"%~dp0runtime\node.exe" servidor\index.js
pause
