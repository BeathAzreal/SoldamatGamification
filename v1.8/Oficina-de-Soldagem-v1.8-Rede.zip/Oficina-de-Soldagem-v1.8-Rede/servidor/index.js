import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { dirname, extname, resolve, sep } from "node:path";
import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { networkInterfaces } from "node:os";
//#region src/dados/eventos.ts
function descompactar(c) {
	const tipo = {
		i: "inicio",
		m: "mover",
		f: "fim"
	};
	return c.lista.map((e) => {
		if (e[0] === "a") return {
			tipo: "ajustes",
			ajustes: {
				alimentacao: e[1],
				tensao: e[2]
			}
		};
		if (e[0] === "p") return {
			tipo: "posicao",
			rolagemGraus: e[1],
			giroGraus: e[2]
		};
		const [k, t, x, y] = e;
		return {
			tipo: tipo[k],
			t,
			x,
			y
		};
	});
}
/** Confere a estrutura (dados importados ou salvos podem estar corrompidos). */
function eventosValidos(c) {
	if (!c || typeof c !== "object") return false;
	const o = c;
	if (o.versao !== 1 || typeof o.t0 !== "number" || !Array.isArray(o.lista)) return false;
	return o.lista.every((e) => Array.isArray(e) && ((e[0] === "a" || e[0] === "p") && e.length === 3 && e.slice(1).every((v) => typeof v === "number" && Number.isFinite(v)) || [
		"i",
		"m",
		"f"
	].includes(e[0]) && e.length === 4 && e.slice(1).every((v) => typeof v === "number" && Number.isFinite(v))));
}
//#endregion
//#region src/modelo/material.ts
var MATERIAIS = {
	"aco-carbono": {
		id: "aco-carbono",
		nome: "Aço de baixo carbono",
		necessidadeFusao: 1,
		efeitoAquecimento: .3,
		ganhoAquecimento: .25,
		tauAquecimentoS: 24,
		fatorDeformacao: 1,
		exigeLimpeza: false,
		aparencia: {
			chapaClara: "#77808b",
			chapaEscura: "#545c66",
			cordao: [
				"#474d55",
				"#6c737b",
				"#959ca4",
				"#c8cdd2"
			],
			brilhoFraco: false,
			tintaTermica: false
		}
	},
	"inox-austenitico": {
		id: "inox-austenitico",
		nome: "Aço inoxidável austenítico",
		necessidadeFusao: .85,
		efeitoAquecimento: .25,
		ganhoAquecimento: .35,
		tauAquecimentoS: 36,
		fatorDeformacao: 1.7,
		exigeLimpeza: false,
		aparencia: {
			chapaClara: "#d3d1cb",
			chapaEscura: "#aba79f",
			cordao: [
				"#726c62",
				"#a09a8f",
				"#cbc6bc",
				"#efede8"
			],
			brilhoFraco: false,
			tintaTermica: true
		}
	},
	aluminio: {
		id: "aluminio",
		nome: "Liga de alumínio",
		necessidadeFusao: 1.8,
		efeitoAquecimento: .8,
		ganhoAquecimento: .3,
		tauAquecimentoS: 16,
		fatorDeformacao: 1.2,
		exigeLimpeza: true,
		aparencia: {
			chapaClara: "#e6ebf1",
			chapaEscura: "#c2cbd6",
			cordao: [
				"#97a2ae",
				"#bcc6d1",
				"#dbe2ea",
				"#f8fafc"
			],
			brilhoFraco: true,
			tintaTermica: false
		}
	}
};
var GASES = {
	"ar-co2": {
		id: "ar-co2",
		nome: "Mistura argônio + CO₂",
		processo: "MAG",
		rendimento: 1,
		fatorFusao: 1,
		materiais: ["aco-carbono"]
	},
	co2: {
		id: "co2",
		nome: "CO₂ puro",
		processo: "MAG",
		rendimento: .94,
		fatorFusao: 1.1,
		materiais: ["aco-carbono"]
	},
	"ar-co2-baixo": {
		id: "ar-co2-baixo",
		nome: "Argônio com baixo teor de CO₂",
		processo: "MAG",
		rendimento: 1,
		fatorFusao: 1,
		materiais: ["inox-austenitico"]
	},
	ar: {
		id: "ar",
		nome: "Argônio puro",
		processo: "MIG",
		rendimento: 1,
		fatorFusao: 1,
		materiais: ["aluminio"]
	}
};
function gasCompativel(gas, material) {
	return GASES[gas].materiais.includes(material);
}
//#endregion
//#region src/modelo/parametros.ts
/**
* Parâmetros do MODELO QUALITATIVO SIMPLIFICADO.
*
* Atenção: nenhum número deste arquivo vem de norma, catálogo de fabricante
* ou medição. Eles foram escolhidos para o jogo ficar jogável e para as
* TENDÊNCIAS ficarem visíveis. As hipóteses estão numeradas (H1, H2, ...)
* e explicadas em docs/HIPOTESES.md.
*/
/** Geometria da peça virtual, em "mm do jogo". Junta de topo ao longo de x, em y = 0. */
var PECA = {
	comprimentoMm: 150,
	larguraChapaMm: 50
};
/**
* Tensão e alimentação são POSIÇÕES DE BOTÃO de 1 a 10, não volts nem m/min.
* O valor de referência (5 / 5,5) reproduz exatamente o modelo da etapa 1.
*/
var AJUSTES = {
	minimo: 1,
	maximo: 10,
	passo: .5,
	alimentacaoReferencia: 5,
	tensaoReferencia: 5.5
};
var MODELO = {
	/**
	* Volume depositado por segundo com a alimentação de referência (mm³/s do jogo) (H1).
	* H87 (v1.8): metade do valor anterior (100), para a solda certa pedir metade da velocidade.
	*/
	taxaDeposicaoMm3s: 50,
	/** Altura do cordão dividida pela largura, na tensão de referência (H3). */
	razaoAlturaLargura: .25,
	/** Razão altura/largura nos extremos do botão de tensão: 1 → 10 (H9). */
	razaoTensaoMinima: .34,
	razaoTensaoMaxima: .16,
	/** Resolução da discretização ao longo da junta (mm). */
	passoMm: .5,
	/** Espalhamento numérico do depósito ao longo da junta, em mm (H4). */
	sigmaPocaMm: 2,
	/** Distância máxima entre pontos de depósito ao subdividir um trecho (mm). */
	subdivisaoMaxMm: .25
};
/** Movimento da tocha / tecimento (H39). Números do jogo. */
var MOVIMENTO = {
	/** Meia amplitude da oscilação lateral escolhida na bancada (mm). */
	amplitudeMm: 2,
	/** Expoente do espalhamento do calor: F × (w₀ ÷ w)^expoente. */
	expoenteFusao: .5,
	/** Oscilações por segundo no desenho da tocha (só visual). */
	frequenciaVisualHz: 2.5
};
var TRAJETORIA = { 
/** Tempo máximo que a tocha leva entre duas leituras do mouse (H5). */
duracaoMaxDeslocamentoMs: 50 };
var VELOCIDADE = {
	/** Janela de tempo usada para medir a velocidade (H6). */
	janelaMs: 200,
	/**
	* Faixa-alvo DESTE JOGO (arbitrária) com a alimentação de referência.
	* Ela cresce junto com a alimentação (H11).
	*/
	alvoMinMms: 4,
	alvoMaxMms: 8
};
/** Critérios da avaliação ao fim da tentativa (H14–H16). Todos são escolhas do jogo. */
var AVALIACAO = {
	/** Abaixo desta largura não consideramos que há cordão (H14). */
	larguraMinimaMm: 1,
	/** Descontado em cada ponta do cordão antes de medir (H14). */
	aparaPontasMm: 5,
	/** Região avaliada menor que isso → nada a avaliar. */
	comprimentoMinimoMm: 10,
	/** Coeficiente de variação da largura: limites das faixas (H15). */
	cvMuitoRegular: .05,
	cvRegular: .12,
	/** Desvio médio do centro em relação à junta: limites das faixas (H16). */
	desvioCentradoMm: 1,
	desvioLeveMm: 2.5
};
/** Explicação e comparação (H20, H22, H24). Todos são escolhas do jogo. */
var EXPLICACAO = {
	/** Tamanho do trecho para medir a velocidade efetiva (H20). */
	trechoMm: 5,
	/**
	* Pausa: trecho com velocidade efetiva abaixo desta fração da mediana dos
	* trechos da própria tentativa (H22). Relativo porque a velocidade "normal"
	* muda muito com a alimentação.
	*/
	pausaFracaoMediana: .4,
	/** Variação de velocidade a partir da qual vale comentar (H22). */
	variacaoRelevante: .1,
	/** Diferenças menores que estas contam como "igual" na comparação (H24). */
	toleranciaFracao: .02,
	toleranciaMm: .3,
	/** Um fator da decomposição de largura só é citado se mudar mais que isso (H25). */
	fatorRelevante: .03
};
/** Índice de fusão sintético (H33, H34). Números do jogo. */
var FUSAO = {
	/**
	* Aporte necessário por mm de espessura (unidades relativas: potência × s ÷ mm).
	* H87 (v1.8): o dobro do valor anterior (0,01677): a mesma potência precisa de
	* duas vezes mais tempo sobre cada mm, ou seja, metade da velocidade.
	*/
	necessidadePorMm: .03354,
	/** Seção a partir da qual o metal acumulado amortece a fusão (mm²). */
	areaAmortecimentoMm2: 25,
	minimoAdequado: 1,
	maximoAdequado: 2,
	/** Acima disso: perfuração prevista. */
	perfuracao: 2.6,
	/** Margem para considerar uma borda coberta (mm). */
	margemBordaMm: .5,
	/** Fator quando o óxido do alumínio não foi removido (H35). */
	fatorSemLimpeza: .6,
	/** Normalização do índice de deformação (H36). */
	normalizacaoDeformacao: 2.07
};
/**
* Distância bico de contato–peça, DBCP/CTWD (H48). A faixa de escolhas (10 a
* 20 mm) cobre o que guias de fabricante indicam para MIG/MAG por curto-
* circuito (≈ 10–12 mm) e um pouco além; a fração resistiva é do jogo.
*/
var DBCP = {
	referenciaMm: 15,
	minimoMm: 8,
	maximoMm: 25,
	/** Opções da bancada (mm). */
	opcoesMm: [
		10,
		15,
		20
	],
	/** Parte da fusão do arame que vem do aquecimento resistivo do arame livre, na referência (H48). */
	fracaoResistiva: .3
};
/** Equilíbrio tensão × alimentação do jogo (H10). Reta e tolerância inventadas. */
var EQUILIBRIO = {
	/** tensão de equilíbrio = base + inclinação × alimentação */
	base: 1.5,
	inclinacao: .8,
	/** Diferença (em pontos de botão) ainda considerada equilibrada. */
	tolerancia: 1
};
/**
* Defeitos visíveis (H50–H57). Todos os números são DO JOGO: as fontes
* consultadas dão a direção (o que piora o quê), não os limiares.
*/
var DEFEITOS = {
	/** Poça de referência (mm² de seção): acima dela a gravidade começa a pesar (H50). */
	areaPocaRefMm2: 10,
	/** Mordedura máxima pelos fatores de regulagem (mm, H52). */
	mordeduraMaxMm: .6,
	/** Mordedura a mais no lado de cima na horizontal, com o metal caindo inteiro (mm, H50/H52). */
	mordeduraCaimentoMm: .4,
	/** Respingos presos por mm de cordão, por unidade de excesso de respingo (H54). */
	respingosPorMm: .35,
	/** Permanência no fim do passe que enche a cratera (ms, H55). */
	enchimentoCrateraMs: 500,
	/** Escama a cada tanto tempo de arco (ms, H56): espaçamento = velocidade × intervalo. */
	intervaloEscamaMs: 240,
	/** Empeno angular por unidade do índice de deformação D (graus, H57). */
	empenoPorD: 1.2,
	empenoMaxGraus: 6
};
//#endregion
//#region src/modelo/juntas.ts
var INFO_JUNTA = {
	topo: {
		nome: "Topo reto",
		resumo: "Bordas retas frente a frente, com uma pequena abertura. A referência.",
		familia: "chanfro",
		rolagemInicialGraus: 0,
		fatorFusao: 1,
		espessuraTesteMm: 3,
		aberturaTesteMm: 1,
		velocidadeReferenciaMms: 6
	},
	v: {
		nome: "Topo em V (60°)",
		resumo: "Chapa grossa com as bordas chanfradas: o metal precisa encher o V. Ande devagar ou faça mais de um passe.",
		familia: "chanfro",
		rolagemInicialGraus: 0,
		fatorFusao: 1.1,
		espessuraTesteMm: 6,
		aberturaTesteMm: 1,
		velocidadeReferenciaMms: 2.5
	},
	t: {
		nome: "Em T (filete)",
		resumo: "Uma chapa em pé sobre a outra; solda de ângulo no canto. Chega na horizontal: tombe a peça 45° para soldar na plana.",
		familia: "filete",
		rolagemInicialGraus: 45,
		fatorFusao: 1.3,
		espessuraTesteMm: 3,
		aberturaTesteMm: 0,
		velocidadeReferenciaMms: 6
	},
	sobreposta: {
		nome: "Sobreposta (filete)",
		resumo: "Uma chapa por cima da outra; solda de ângulo na borda de cima. Chega na horizontal.",
		familia: "filete",
		rolagemInicialGraus: 45,
		fatorFusao: 1.55,
		espessuraTesteMm: 2,
		aberturaTesteMm: 0,
		velocidadeReferenciaMms: 7
	},
	canto: {
		nome: "De canto (externa)",
		resumo: "Duas chapas formando um L, soldadas por fora. Chega quase de cabeça para baixo: tombe até a face ficar para cima.",
		familia: "filete",
		rolagemInicialGraus: 135,
		fatorFusao: 1.1,
		espessuraTesteMm: 3,
		aberturaTesteMm: 0,
		velocidadeReferenciaMms: 6
	}
};
function juntaDe(ctx) {
	return ctx.junta ?? "topo";
}
var TAN30 = Math.tan(Math.PI / 6);
/** Quanto o reforço do V passa da abertura do chanfro, no mínimo (mm, os dois lados somados). */
var SOBRA_V_MM = 1.4;
var R2 = Math.SQRT2;
/** Face de raiz do chanfro em V (mm): a parte reta que sobra embaixo. */
function faceRaizMm(d) {
	return Math.min(1, d.espessuraMm / 3);
}
/** Área do chanfro em V por mm de junta (mm²): abertura × espessura + os dois chanfros de 30°. */
function areaChanfroMm2(d) {
	const p = faceRaizMm(d);
	return d.aberturaMm * d.espessuraMm + (d.espessuraMm - p) ** 2 * TAN30;
}
/** Largura da abertura do V no topo das chapas (mm). */
function larguraTopoChanfroMm(d) {
	return d.aberturaMm + 2 * (d.espessuraMm - faceRaizMm(d)) * TAN30;
}
/** Abertura que o cordão precisa cobrir na face (H34): a fresta no topo reto, o V no chanfro; nada no filete. */
function aberturaNaFaceMm(junta, d) {
	if (junta === "topo") return d.aberturaMm;
	if (junta === "v") return larguraTopoChanfroMm(d);
	return 0;
}
/** Altura do metal no V (mm, medida da raiz) para uma área depositada A < área do chanfro. */
function nivelNoChanfro(area, d) {
	const a = d.aberturaMm;
	const p = faceRaizMm(d);
	if (area <= a * p) return a > 0 ? area / a : 0;
	const resto = area - a * p;
	const k = TAN30;
	const u = (-a + Math.sqrt(a * a + 4 * k * resto)) / (2 * k);
	return Math.min(d.espessuraMm, p + u);
}
/** Convexidade do filete pela forma do arco (H9): tensão baixa (razão alta) → convexo; alta → plano ou côncavo. */
function convexidadeFilete(razao) {
	return Math.min(.25, Math.max(-.15, razao - .25));
}
/**
* Seção do cordão NA JUNTA (H46), a partir da seção de metal depositado
* (cordao.ts). Na junta de topo é a seção de sempre (domo sobre a face; o
* metal que entra na fresta não é modelado, H18). No V o metal enche
* primeiro o chanfro e só o que sobra vira reforço; se faltar, o V fica
* aberto (altura negativa = abaixo do topo). No filete o metal enche o
* entalhe de 90°: pernas iguais com a tocha na raiz, convexidade pela tensão.
* Oscilação lateral e arco instável (H39, H44) entram pela razão entre a
* largura de base e a largura só pela área.
*/
function secaoNaJunta(base, junta, d, razao) {
	if (base.areaMm2 <= 0 || junta === "topo" && d.aberturaMm <= 0) return {
		...base,
		areaReforcoMm2: base.areaMm2,
		enchimento: junta === "v" ? 0 : 1
	};
	const A = base.areaMm2;
	if (junta === "topo") {
		const a2 = d.aberturaMm / 2;
		const esq = Math.max(-a2, base.yCentroMm - base.larguraMm / 2);
		const dir = Math.min(a2, base.yCentroMm + base.larguraMm / 2);
		const sobreFresta = Math.max(0, dir - esq);
		if (sobreFresta <= 0) return {
			...base,
			areaReforcoMm2: A,
			enchimento: 1
		};
		const Af = sobreFresta * d.espessuraMm;
		if (A < Af) {
			const nivel = A / sobreFresta;
			return {
				...base,
				larguraMm: sobreFresta,
				yCentroMm: (esq + dir) / 2,
				alturaMm: -(d.espessuraMm - nivel),
				razaoAlturaLargura: 0,
				areaReforcoMm2: 0,
				enchimento: A / Af
			};
		}
		const excesso = A - Af;
		const largura = Math.max(d.aberturaMm, base.larguraMm * Math.sqrt(excesso / A));
		const altura = 1.5 * excesso / largura;
		return {
			...base,
			larguraMm: largura,
			alturaMm: altura,
			razaoAlturaLargura: altura / largura,
			areaReforcoMm2: excesso,
			enchimento: A / Af
		};
	}
	if (junta === "v") {
		const Ach = areaChanfroMm2(d);
		const wTopo = larguraTopoChanfroMm(d);
		if (A < Ach) {
			const y = nivelNoChanfro(A, d);
			const p = faceRaizMm(d);
			const largura = d.aberturaMm + 2 * Math.max(0, y - p) * TAN30;
			return {
				...base,
				larguraMm: largura,
				alturaMm: -(d.espessuraMm - y),
				razaoAlturaLargura: 0,
				areaReforcoMm2: 0,
				enchimento: A / Ach
			};
		}
		const excesso = A - Ach;
		const pelaArea = base.larguraMm * Math.sqrt(excesso / A);
		const largura = Math.max(wTopo + SOBRA_V_MM, pelaArea);
		const altura = 1.5 * excesso / largura;
		return {
			...base,
			larguraMm: largura,
			alturaMm: altura,
			razaoAlturaLargura: altura / largura,
			areaReforcoMm2: excesso,
			enchimento: A / Ach
		};
	}
	const c = convexidadeFilete(razao);
	const z0 = Math.sqrt(A / (.5 + 4 / 3 * c));
	const soPelaArea = Math.sqrt(A / (2 / 3 * razao));
	const z = z0 * (soPelaArea > 0 ? base.larguraMm / soPelaArea : 1);
	const delta = Math.max(-.8 * z, Math.min(.8 * z, base.yCentroMm * R2));
	const z1 = z + delta;
	const z2 = z - delta;
	const face = Math.hypot(z1, z2);
	return {
		...base,
		larguraMm: face,
		alturaMm: c * face,
		razaoAlturaLargura: c,
		yCentroMm: delta / R2,
		areaReforcoMm2: A,
		enchimento: 1,
		pernasMm: [z1, z2]
	};
}
1 / R2, 1 / R2;
-1 / R2, 1 / R2;
var POSICAO_PLANA = {
	rolagemGraus: 0,
	giroGraus: 0
};
/**
* Gravidade vista da junta. A câmera olha sempre de frente para a face;
* tombar a peça φ leva a gravidade de "para dentro da face" (plana) para
* "para baixo na tela" (90°) e "para fora da face" (180°, sobrecabeça). O
* giro θ no plano decide se ela fica de lado (horizontal) ou ao longo da
* junta (vertical).
*/
function gravidade(p) {
	const f = p.rolagemGraus * Math.PI / 180;
	const q = p.giroGraus * Math.PI / 180;
	return {
		t: Math.sin(q) * Math.sin(f),
		n: Math.cos(q) * Math.sin(f),
		w: -Math.cos(f)
	};
}
var SEM_EFEITO = {
	razao: 1,
	fusao: 1,
	desvioMm: 0
};
/**
* Efeito da gravidade sobre a poça (H47), em `sentido` de avanço ao longo
* da junta (+1, −1 ou 0 parado). Direções da prática: de cabeça para baixo
* o metal tende a pingar (cordão mais convexo, funde menos); na vertical a
* poça escorre — subindo funde mais e fica convexo, descendo funde menos e
* fica raso; na horizontal o metal escorre para a chapa de baixo. Na plana
* nada muda (as etapas anteriores ficam iguais). Os números são do jogo.
*/
function efeitoPosicao(g, sentido) {
	if (g.w <= -.999999) return SEM_EFEITO;
	const cabeca = Math.max(0, g.w);
	const aoLongo = g.t * Math.sign(sentido);
	const descendo = Math.max(0, aoLongo);
	const subindo = Math.max(0, -aoLongo);
	const lado = Math.abs(g.n);
	return {
		razao: 1 + .35 * cabeca + .25 * subindo - .25 * descendo + .1 * lado,
		fusao: Math.max(.3, 1 - .2 * cabeca + .15 * subindo - .3 * descendo),
		desvioMm: .8 * g.n
	};
}
//#endregion
//#region src/missoes/catalogo.ts
/** Diâmetros de arame da máquina: todos ficam à escolha em todas as missões. */
var DIAMETROS_ARAME_MM = [
	.8,
	1,
	1.2
];
var GEOMETRIA_BASE = {
	comprimentoMm: PECA.comprimentoMm,
	larguraChapaMm: PECA.larguraChapaMm
};
var COMUM = {
	processo: "MIG/MAG",
	equipamentos: [
		"Fonte de tensão constante (botões de tensão e de alimentação, de 1 a 10)",
		"Tocha MIG/MAG com bico e regulador de gás",
		"Polaridade fixa: corrente contínua, eletrodo positivo (CC+)"
	]
};
/** Peça sobre um posicionador: pode ser tombada e girada com o arco fechado. */
var LIVRE = (junta) => ({
	rolagemGraus: INFO_JUNTA[junta].rolagemInicialGraus,
	giroGraus: 0,
	fixa: false
});
var MISSOES = [
	{
		id: "suporte-carbono",
		versao: 1,
		titulo: "Suporte de prateleira",
		setor: "Indústria",
		contexto: "Uma serralheria fabrica suportes para as prateleiras do almoxarifado de uma escola. Você une as duas chapas que formam a base de um suporte.",
		finalidade: "Base de suporte que sustenta caixas de material escolar.",
		material: "aco-carbono",
		condicaoFornecimento: "Chapa laminada, cortada em guilhotina, superfície limpa e sem óleo.",
		geometria: {
			...GEOMETRIA_BASE,
			espessuraMm: 3,
			aberturaMm: 1,
			junta: "topo"
		},
		montagem: LIVRE("topo"),
		...COMUM,
		junta: "Junta de topo (bordas frente a frente, com abertura)",
		tipoSolda: "Solda em chanfro reto (bordas retas), por um lado",
		posicao: "Plana (a peça está num posicionador)",
		trecho: {
			inicioMm: 10,
			fimMm: 140
		},
		requisitos: {
			larguraMinMm: 6,
			larguraMaxMm: 9,
			reforcoMaxMm: 3,
			alinhamentoMm: 1.5
		},
		consumiveis: {
			diametrosMm: DIAMETROS_ARAME_MM,
			gases: ["ar-co2", "co2"]
		},
		tentativas: {
			aprendiz: 5,
			profissional: 3
		},
		integridadeMinima: {
			aprendiz: .85,
			profissional: .95
		},
		desafio: "Missão de referência: equilibrar o tamanho do cordão e a fusão."
	},
	{
		id: "inox-equipamento",
		versao: 3,
		titulo: "Tampo de mesa de preparo",
		setor: "Comércio",
		contexto: "Uma empresa de equipamentos para cozinhas prepara a mesa de uma cozinha comunitária. Você une as chapas de inox do tampo.",
		finalidade: "Tampo plano de mesa de preparo de alimentos.",
		material: "inox-austenitico",
		condicaoFornecimento: "Chapa de inox austenítico laminada a frio, com película protetora retirada.",
		geometria: {
			...GEOMETRIA_BASE,
			espessuraMm: 2,
			aberturaMm: .5,
			junta: "topo"
		},
		montagem: LIVRE("topo"),
		...COMUM,
		junta: "Junta de topo (bordas frente a frente, com abertura pequena)",
		tipoSolda: "Solda em chanfro reto, por um lado",
		posicao: "Plana (a peça está num posicionador)",
		trecho: {
			inicioMm: 15,
			fimMm: 135
		},
		requisitos: {
			larguraMinMm: 5,
			larguraMaxMm: 7.5,
			reforcoMaxMm: 2.5,
			alinhamentoMm: 1.2
		},
		consumiveis: {
			diametrosMm: DIAMETROS_ARAME_MM,
			gases: ["ar-co2-baixo"]
		},
		tentativas: {
			aprendiz: 5,
			profissional: 3
		},
		integridadeMinima: {
			aprendiz: .85,
			profissional: .95
		},
		desafio: "Fundir sem colocar calor demais: o inox deforma mais que o aço carbono."
	},
	{
		id: "mobiliario-chapa-fina",
		versao: 3,
		titulo: "Assento de banco",
		setor: "Sociedade",
		contexto: "Uma oficina monta bancos metálicos para a biblioteca pública do bairro. O assento é uma chapa fina sobreposta à travessa: você solda a borda de cima.",
		finalidade: "Assento de banco de leitura, sem cantos vivos nem furos.",
		material: "aco-carbono",
		condicaoFornecimento: "Chapa fina laminada a frio, superfície limpa.",
		geometria: {
			...GEOMETRIA_BASE,
			espessuraMm: 1.5,
			aberturaMm: 0,
			junta: "sobreposta"
		},
		montagem: LIVRE("sobreposta"),
		...COMUM,
		junta: "Junta sobreposta (uma chapa por cima da outra)",
		tipoSolda: "Solda de ângulo (filete) na borda da chapa de cima",
		posicao: "Chega na horizontal (2F); o posicionador permite tombar para a plana",
		trecho: {
			inicioMm: 20,
			fimMm: 130
		},
		requisitos: {
			larguraMinMm: 4.5,
			larguraMaxMm: 6.5,
			reforcoMaxMm: 1.5,
			alinhamentoMm: 1.2
		},
		consumiveis: {
			diametrosMm: DIAMETROS_ARAME_MM,
			gases: ["ar-co2"]
		},
		tentativas: {
			aprendiz: 5,
			profissional: 3
		},
		integridadeMinima: {
			aprendiz: .85,
			profissional: .95
		},
		desafio: "Chapa fina: ande rápido para não furar a borda de cima, sem deixar de fundir a de baixo."
	},
	{
		id: "aluminio-componente",
		versao: 3,
		titulo: "Suporte de painel solar",
		setor: "Sociedade",
		contexto: "Uma oficina fabrica suportes leves para os painéis solares de um posto de saúde. Você solda a nervura em pé sobre a base de alumínio.",
		finalidade: "Peça leve de suporte, exposta ao tempo.",
		material: "aluminio",
		condicaoFornecimento: "Chapa de liga de alumínio com a camada natural de óxido na superfície.",
		geometria: {
			...GEOMETRIA_BASE,
			espessuraMm: 3,
			aberturaMm: 0,
			junta: "t"
		},
		montagem: LIVRE("t"),
		...COMUM,
		junta: "Junta em T (nervura em pé sobre a base)",
		tipoSolda: "Solda de ângulo (filete), por um lado",
		posicao: "Chega na horizontal (2F); o posicionador permite tombar para a plana",
		trecho: {
			inicioMm: 10,
			fimMm: 140
		},
		requisitos: {
			larguraMinMm: 6,
			larguraMaxMm: 9,
			reforcoMaxMm: 1.8,
			alinhamentoMm: 1.5
		},
		consumiveis: {
			diametrosMm: DIAMETROS_ARAME_MM,
			gases: ["ar"]
		},
		tentativas: {
			aprendiz: 6,
			profissional: 4
		},
		integridadeMinima: {
			aprendiz: .85,
			profissional: .95
		},
		desafio: "Pede muito calor no começo; a peça esquenta e é preciso acelerar. O óxido deve ser removido."
	},
	{
		id: "estrutura-leve",
		aberturasPlanejadas: 2,
		versao: 1,
		titulo: "Estrutura metálica leve",
		setor: "Sociedade",
		contexto: "Uma serralheria monta o quadro da cobertura de um ponto de ônibus. Você emenda duas chapas grossas da viga, chanfradas em V.",
		finalidade: "Emenda de viga que segura a cobertura.",
		material: "aco-carbono",
		condicaoFornecimento: "Chapa grossa com as bordas chanfradas a 30° (V de 60°) e face de raiz de 1 mm.",
		geometria: {
			...GEOMETRIA_BASE,
			espessuraMm: 6,
			aberturaMm: 1,
			junta: "v"
		},
		montagem: LIVRE("v"),
		...COMUM,
		junta: "Junta de topo com chanfro em V (60°)",
		tipoSolda: "Solda em chanfro em V, por um lado; o V precisa ficar cheio",
		posicao: "Plana (a peça está num posicionador)",
		trecho: {
			inicioMm: 10,
			fimMm: 140
		},
		requisitos: {
			larguraMinMm: 7.5,
			larguraMaxMm: 10,
			reforcoMaxMm: 3,
			alinhamentoMm: 1.5
		},
		consumiveis: {
			diametrosMm: DIAMETROS_ARAME_MM,
			gases: ["ar-co2", "co2"]
		},
		tentativas: {
			aprendiz: 6,
			profissional: 4
		},
		integridadeMinima: {
			aprendiz: .8,
			profissional: .9
		},
		desafio: "Encher o V: um passe devagar ou dois passes (raiz e acabamento). Rápido demais deixa o chanfro aberto."
	},
	{
		id: "corrimao-inox",
		versao: 1,
		titulo: "Corrimão da rampa",
		setor: "Sociedade",
		contexto: "A rampa de acesso do posto de saúde ganha um corrimão de inox. O montante já está chumbado no chão: você solda a junta de canto do perfil em pé, sem poder girar a peça.",
		finalidade: "Corrimão de acessibilidade, liso ao toque e sem furos.",
		material: "inox-austenitico",
		condicaoFornecimento: "Perfil de inox montado no lugar, limpo com escova de inox.",
		geometria: {
			...GEOMETRIA_BASE,
			espessuraMm: 2,
			aberturaMm: 0,
			junta: "canto"
		},
		montagem: {
			rolagemGraus: 90,
			giroGraus: 90,
			fixa: true
		},
		...COMUM,
		junta: "Junta de canto externa (L), já presa na estrutura",
		tipoSolda: "Solda de ângulo por fora do canto",
		posicao: "Vertical (3F), peça fixa: escolha subir ou descer",
		trecho: {
			inicioMm: 15,
			fimMm: 135
		},
		requisitos: {
			larguraMinMm: 4.5,
			larguraMaxMm: 7,
			reforcoMaxMm: 2,
			alinhamentoMm: 1.2
		},
		consumiveis: {
			diametrosMm: DIAMETROS_ARAME_MM,
			gases: ["ar-co2-baixo"]
		},
		tentativas: {
			aprendiz: 6,
			profissional: 4
		},
		integridadeMinima: {
			aprendiz: .8,
			profissional: .9
		},
		desafio: "Na vertical a poça escorre: subindo funde mais; descendo funde pouco. A peça não gira."
	}
];
/** Requisitos ajustados à dificuldade (docs/MISSOES.md). No Fácil, 1 mm de folga na largura e no alinhamento (H88). */
function requisitosEfetivos(m, d) {
	const folga = d === "aprendiz" ? 1 : 0;
	return {
		larguraMinMm: m.requisitos.larguraMinMm - folga,
		larguraMaxMm: m.requisitos.larguraMaxMm + folga,
		reforcoMaxMm: m.requisitos.reforcoMaxMm,
		alinhamentoMm: m.requisitos.alinhamentoMm + folga,
		integridadeMinima: m.integridadeMinima[d],
		tentativas: m.tentativas[d]
	};
}
function preparoPadrao(m) {
	return {
		diametroArameMm: m.consumiveis.diametrosMm[0],
		gas: m.consumiveis.gases[0],
		oxidoRemovido: false,
		tecnica: "neutra",
		movimento: "reto",
		dbcpMm: DBCP.referenciaMm
	};
}
/** Erros se a combinação não for permitida pela missão (nunca deve passar para a simulação). */
function validarPreparo(m, p) {
	const erros = [];
	if (!m.consumiveis.diametrosMm.includes(p.diametroArameMm)) erros.push("Diâmetro de arame não previsto na missão.");
	if (!m.consumiveis.gases.includes(p.gas)) erros.push("Gás não previsto na missão.");
	if (!gasCompativel(p.gas, m.material)) erros.push("Gás incompatível com o material.");
	if (p.dbcpMm !== void 0 && !DBCP.opcoesMm.includes(p.dbcpMm)) erros.push("Distância bico–peça fora das opções da bancada.");
	return erros;
}
function contextoDaMissao(m, p) {
	const erros = validarPreparo(m, p);
	if (erros.length) throw new Error(erros.join(" "));
	return {
		material: m.material,
		espessuraMm: m.geometria.espessuraMm,
		aberturaMm: m.geometria.aberturaMm,
		diametroArameMm: p.diametroArameMm,
		gas: p.gas,
		oxidoRemovido: MATERIAIS[m.material].exigeLimpeza ? p.oxidoRemovido : true,
		tecnica: p.tecnica ?? "neutra",
		movimento: "reto",
		junta: m.geometria.junta,
		posicaoInicial: {
			rolagemGraus: m.montagem.rolagemGraus,
			giroGraus: m.montagem.giroGraus
		},
		posicaoFixa: m.montagem.fixa,
		dbcpMm: p.dbcpMm ?? DBCP.referenciaMm
	};
}
({ ...MISSOES[0] });
//#endregion
//#region src/modelo/processo.ts
var AJUSTES_PADRAO = {
	alimentacao: AJUSTES.alimentacaoReferencia,
	tensao: AJUSTES.tensaoReferencia
};
/** H48: DBCP usada pelo modelo; valores fora da faixa do jogo voltam ao padrão. */
function dbcpDe(ctx) {
	const d = ctx.dbcpMm;
	return typeof d === "number" && Number.isFinite(d) && d >= DBCP.minimoMm && d <= DBCP.maximoMm ? d : DBCP.referenciaMm;
}
/**
* Ângulo de avanço (H38): inclinação da tocha no plano que contém a junta,
* medida da normal à face. Positivo = empurrando (a tocha aponta para onde
* vai). O jogo usa só três posições; 20° fica na faixa usual de 10–20° das
* apostilas. Os fatores de forma e fusão são do jogo.
*/
var INFO_TECNICA = {
	empurrando: {
		nome: "Empurrando",
		resumo: "Tocha inclinada para a frente: cordão mais largo e baixo, menos fusão.",
		anguloAvancoGraus: 20,
		forma: .88,
		fusao: .9
	},
	neutra: {
		nome: "Neutra",
		resumo: "Tocha a prumo: comportamento de referência.",
		anguloAvancoGraus: 0,
		forma: 1,
		fusao: 1
	},
	puxando: {
		nome: "Puxando",
		resumo: "Tocha inclinada para trás: cordão mais alto e estreito, mais fusão.",
		anguloAvancoGraus: -20,
		forma: 1.12,
		fusao: 1.12
	}
};
function tecnicaDe(ctx) {
	return ctx.tecnica ?? "neutra";
}
/** k: espalhamento lateral σ = amplitude × k (H39). */
var INFO_MOVIMENTO = {
	reto: {
		nome: "Linha reta",
		resumo: "A tocha segue a junta sem oscilar: cordão estreito, calor concentrado no centro.",
		k: 0
	},
	"zigue-zague": {
		nome: "Zigue-zague",
		resumo: "Vaivém lateral contínuo: cordão mais largo e baixo, calor mais espalhado. Avance mais devagar.",
		k: .58
	},
	"meia-lua": {
		nome: "Meia-lua",
		resumo: "Arcos com pausa nas pontas: o mais largo, cobre melhor as bordas, funde menos no centro.",
		k: .8
	},
	circulos: {
		nome: "Círculos",
		resumo: "Pequenos círculos sobre a junta: largura intermediária entre zigue-zague e meia-lua.",
		k: .71
	}
};
function movimentoDe(ctx) {
	return ctx.movimento ?? "reto";
}
/** σ lateral que o movimento escolhido acrescenta a cada depósito (mm, H39). */
function espalhamentoDoMovimento(ctx) {
	return MOVIMENTO.amplitudeMm * INFO_MOVIMENTO[movimentoDe(ctx)].k;
}
/**
* O contexto do modo livre das etapas 1–4: reproduz exatamente o modelo
* antigo, cordão sobre chapa (sem fresta). Desde a v1.3 o metal enche a
* fresta da junta de topo antes de virar reforço; com abertura 0 nada muda.
*/
var CONTEXTO_PADRAO = {
	material: "aco-carbono",
	espessuraMm: 3,
	aberturaMm: 0,
	diametroArameMm: 1,
	gas: "ar-co2",
	oxidoRemovido: true
};
function limitarAjustes(a) {
	const limitar = (v) => Math.min(AJUSTES.maximo, Math.max(AJUSTES.minimo, v));
	return {
		alimentacao: limitar(a.alimentacao),
		tensao: limitar(a.tensao)
	};
}
/**
* H1: volume de arame que a máquina empurra por segundo, RELATIVO (1 =
* alimentação 5 com arame de 1,0 mm): velocidade do arame × seção do arame.
* É conservação de massa: não depende da tensão nem da DBCP.
*/
function volumeArameRelativo(a, ctx = CONTEXTO_PADRAO) {
	return a.alimentacao / AJUSTES.alimentacaoReferencia * ctx.diametroArameMm ** 2;
}
/**
* H28 (revista na v1.3) + H48: corrente RELATIVA (1 = alimentação 5, arame
* de 1,0 mm, DBCP 15 mm). Numa fonte de tensão constante a corrente não é um
* botão: é a que funde o arame na velocidade em que ele chega. Forma da
* relação de fusão do eletrodo (Lesnewich, 1958): volume fundido = a·I +
* b·L·I²/A — o arco (∝ I) mais o aquecimento resistivo do arame livre
* (∝ L·I²/A, A = seção do arame). Normalizada na referência, com a fração
* resistiva DBCP.fracaoResistiva (número do jogo):
*   V = (1 − r)·i + r·(L/L₀)·i²/d²  →  i = raiz positiva.
* Consequências (direção documentada; números do jogo): a corrente cresce
* menos que a alimentação; mais DBCP → menos corrente para o mesmo arame.
*/
function correnteRelativa(a, ctx = CONTEXTO_PADRAO) {
	const v = volumeArameRelativo(a, ctx);
	if (v <= 0) return 0;
	const r = DBCP.fracaoResistiva;
	const b = r * (dbcpDe(ctx) / DBCP.referenciaMm) / ctx.diametroArameMm ** 2;
	return (-(1 - r) + Math.sqrt((1 - r) ** 2 + 4 * b * v)) / (2 * b);
}
/** H1 + H29: volume depositado por segundo ∝ volume de arame × rendimento do gás. Tensão e DBCP não entram. */
function taxaDeposicao(a, ctx = CONTEXTO_PADRAO) {
	return MODELO.taxaDeposicaoMm3s * volumeArameRelativo(a, ctx) * GASES[ctx.gas].rendimento;
}
/**
* H31: potência relativa do arco = corrente relativa × tensão relativa (a
* forma U·I da energia do arco; o aporte por mm divide pela velocidade, H33).
*/
function potenciaRelativa(a, ctx = CONTEXTO_PADRAO) {
	return correnteRelativa(a, ctx) * (a.tensao / AJUSTES.tensaoReferencia);
}
/** H9 + H38: forma da seção considerando também a técnica de deslocamento. */
function razaoEfetiva(a, ctx = CONTEXTO_PADRAO) {
	return razaoAlturaLargura(a) * INFO_TECNICA[tecnicaDe(ctx)].forma;
}
/**
* H9: mais tensão → cordão mais achatado (razão altura/largura menor).
* Interpolação linear entre os extremos do botão — forma escolhida para o
* jogo, só a DIREÇÃO da tendência é o que se quer mostrar.
*/
function razaoAlturaLargura(a) {
	const f = (a.tensao - AJUSTES.minimo) / (AJUSTES.maximo - AJUSTES.minimo);
	return MODELO.razaoTensaoMinima + (MODELO.razaoTensaoMaxima - MODELO.razaoTensaoMinima) * f;
}
/**
* H10 + H30: mais corrente pede mais tensão. Fora da tolerância o arco fica
* "curto" ou "longo". Isso só gera aviso e efeito visual.
*/
function equilibrioArco(a, ctx = CONTEXTO_PADRAO) {
	const alimentacaoEquivalente = correnteRelativa(a, ctx) * AJUSTES.alimentacaoReferencia;
	const tensaoEquilibrio = EQUILIBRIO.base + EQUILIBRIO.inclinacao * alimentacaoEquivalente;
	const desvio = a.tensao - tensaoEquilibrio;
	return {
		tensaoEquilibrio,
		desvio,
		condicao: desvio < -EQUILIBRIO.tolerancia ? "curto" : desvio > EQUILIBRIO.tolerancia ? "longo" : "equilibrado"
	};
}
/**
* H11/H17: a meta do jogo é uma faixa fixa de ÁREA de seção — a que se obtém
* com a alimentação de referência andando dentro da faixa-alvo de velocidade.
*/
function areaAlvo() {
	return {
		minMm2: MODELO.taxaDeposicaoMm3s / VELOCIDADE.alvoMaxMms,
		maxMm2: MODELO.taxaDeposicaoMm3s / VELOCIDADE.alvoMinMms
	};
}
//#endregion
//#region src/modelo/fusao.ts
var DESCRICAO_ESTADO = {
	"sem-cordao": "sem cordão",
	perfuracao: "perfuração prevista",
	enchimento: "junta não preenchida",
	borda: "borda da junta não coberta",
	falta: "falta de fusão prevista",
	adequada: "fusão adequada prevista",
	excessiva: "fusão excessiva prevista"
};
/** Mesmo espalhamento do cordão (H4): o calor também não fica num ponto só. */
function suavizar(v, passoMm) {
	const sigma = MODELO.sigmaPocaMm / passoMm;
	const raio = Math.ceil(3 * sigma);
	const pesos = Array.from({ length: 2 * raio + 1 }, (_, k) => Math.exp(-.5 * ((k - raio) / sigma) ** 2));
	const saida = new Float64Array(v.length);
	for (let i = 0; i < v.length; i++) {
		let soma = 0;
		let pesoTotal = 0;
		for (let k = -raio; k <= raio; k++) {
			const j = i + k;
			if (j < 0 || j >= v.length) continue;
			soma += v[j] * pesos[k + raio];
			pesoTotal += pesos[k + raio];
		}
		saida[i] = soma / pesoTotal;
	}
	return saida;
}
/** Aporte relativo por mm que funde exatamente a espessura (F = 1); a junta muda quanto calor é preciso (H46). */
function aporteNecessario(ctx) {
	return FUSAO.necessidadePorMm * ctx.espessuraMm * MATERIAIS[ctx.material].necessidadeFusao * INFO_JUNTA[juntaDe(ctx)].fatorFusao;
}
/** Metal acumulado sob o arco amortece a fusão (H33). */
function amortecimento(areaMm2) {
	return 1 / (1 + (areaMm2 / FUSAO.areaAmortecimentoMm2) ** 2);
}
function analisarFusao(cordao, percurso, ctx) {
	const passo = cordao.passoMm;
	const efetivo = suavizar(percurso.copiaDosAportesEfetivos(), passo);
	const bruto = suavizar(percurso.copiaDosAportes(), passo);
	const necessario = aporteNecessario(ctx);
	const limpeza = MATERIAIS[ctx.material].exigeLimpeza && !ctx.oxidoRemovido ? FUSAO.fatorSemLimpeza : 1;
	const gas = GASES[ctx.gas].fatorFusao * INFO_TECNICA[tecnicaDe(ctx)].fusao;
	return Array.from({ length: cordao.nPosicoes }, (_, i) => {
		const s = cordao.secao(i);
		const espalhamento = s.larguraMm > 0 ? (s.larguraSemOscilacaoMm / s.larguraMm) ** MOVIMENTO.expoenteFusao : 1;
		const indice = efetivo[i] / passo / necessario * amortecimento(s.areaMm2) * gas * limpeza * espalhamento;
		let estado;
		if (s.larguraMm < 1) estado = "sem-cordao";
		else if (indice > FUSAO.perfuracao) estado = "perfuracao";
		else if ((s.enchimento ?? 1) < 1) estado = "enchimento";
		else if (margemCoberturaBordas(s, ctx) < 0) estado = "borda";
		else if (indice < FUSAO.minimoAdequado) estado = "falta";
		else if (indice <= FUSAO.maximoAdequado) estado = "adequada";
		else estado = "excessiva";
		return {
			xMm: s.xMm,
			indice,
			aporteMm: bruto[i] / passo,
			estado
		};
	});
}
/**
* Margem em mm até o critério de cobertura (H34/H46).
* Negativa = borda descoberta; zero ou positiva = atende ao critério.
*/
function margemCoberturaBordas(s, ctx) {
	const junta = juntaDe(ctx);
	if (INFO_JUNTA[junta].familia === "filete") {
		if (!s.pernasMm) return 0;
		return Math.min(...s.pernasMm) - .5 * Math.max(...s.pernasMm);
	}
	return s.larguraMm / 2 - Math.abs(s.yCentroMm) - aberturaNaFaceMm(junta, ctx) / 2 - FUSAO.margemBordaMm;
}
/**
* Índice de deformação D (H36): calor colocado além do necessário, vezes a
* tendência do material a deformar. Média sobre as posições com cordão.
*/
function indiceDeformacao(pontos, ctx) {
	const comCordao = pontos.filter((p) => p.estado !== "sem-cordao");
	if (comCordao.length === 0) return 0;
	return comCordao.reduce((s, p) => s + p.aporteMm, 0) / comCordao.length / aporteNecessario(ctx) * MATERIAIS[ctx.material].fatorDeformacao / FUSAO.normalizacaoDeformacao;
}
//#endregion
//#region src/modelo/defeitos.ts
var lim01 = (v) => v <= 0 ? 0 : v >= 1 ? 1 : v;
/** Sorteio fixo em [0, 1) para a fatia i e o canal k (mesma entrada → mesmo número). */
function sorteioFixo(i, k) {
	let h = (Math.imul(i + 1, 2654435761) ^ Math.imul(k + 7, 2246822507)) >>> 0;
	h = Math.imul(h ^ h >>> 16, 2146121005) >>> 0;
	h = Math.imul(h ^ h >>> 15, 2221713035) >>> 0;
	return ((h ^ h >>> 16) >>> 0) / 4294967296;
}
/** Mordedura que já conta como defeito (mm): 10 % da espessura, no mínimo 0,2 mm (ordem de grandeza da ISO 5817, nível C). */
function limiteMordeduraMm(ctx) {
	return Math.max(.2, .1 * ctx.espessuraMm);
}
function analisarDefeitos(e) {
	const { cordao, percurso, contexto: ctx } = e;
	const n = cordao.nPosicoes;
	const passo = cordao.passoMm;
	const fusao = e.fusao ?? analisarFusao(cordao, percurso, ctx);
	const vRef = INFO_JUNTA[juntaDe(ctx)].velocidadeReferenciaMms;
	const novo = () => new Float32Array(n);
	const a = {
		n,
		passoMm: passo,
		caimento: novo(),
		rolos: novo(),
		gotejamento: novo(),
		mordeduraMenos: novo(),
		mordeduraMais: novo(),
		sobreposicaoMenos: novo(),
		sobreposicaoMais: novo(),
		cratera: novo(),
		porosidade: novo(),
		calor: novo(),
		escamaFase: novo(),
		escamaDir: new Int8Array(n),
		gotas: [],
		respingos: [],
		poros: [],
		empenoGraus: 0,
		limiteMordeduraMm: limiteMordeduraMm(ctx),
		ocorrencias: []
	};
	const secoes = Array.from({ length: n }, (_, i) => cordao.secao(i));
	const comCordao = secoes.filter((s) => s.larguraMm >= 1);
	if (comCordao.length === 0) return a;
	const areas = comCordao.map((s) => s.areaMm2).sort((x, y) => x - y);
	const areaMediana = areas[Math.floor(areas.length / 2)];
	const permanencia = suavizar(percurso.copiaDasPermanencias(), passo);
	const aluminioSujo = ctx.material === "aluminio" && !ctx.oxidoRemovido;
	const dbcp = dbcpDe(ctx);
	const porosidadeBase = (aluminioSujo ? .55 : 0) + (dbcp >= 20 ? .2 : dbcp > 17 ? .1 : 0) + (ctx.gas === "ar" && ctx.material !== "aluminio" ? .15 : 0);
	const respingoGas = ctx.gas === "co2" ? 1.6 : 1;
	const respingoDbcp = dbcp >= 20 ? .1 : 0;
	for (let i = 0; i < n; i++) {
		const s = secoes[i];
		const F = fusao[i]?.indice ?? 0;
		a.calor[i] = F;
		if (s.larguraMm < 1) continue;
		const f = cordao.fisica(i);
		const instab = f.instabilidade;
		const reforco = s.areaReforcoMm2 ?? s.areaMm2;
		const P = (reforco + .3 * Math.max(0, s.areaMm2 - reforco)) / DEFEITOS.areaPocaRefMm2 * (.6 + .4 * Math.min(2, F));
		const afinamento = lim01(s.areaMm2 / (.5 * areaMediana));
		const vRel = permanencia[i] > 0 ? Math.min(4, passo / (permanencia[i] / 1e3) / vRef) : 4;
		a.gotejamento[i] = lim01((P * f.cabeca - 1) / .6);
		const desc = lim01((P * Math.max(0, f.descida) - .9) / .6);
		const sub = lim01((P * Math.max(0, -f.descida) - 1) / .6);
		a.rolos[i] = Math.max(desc, sub);
		const caim = Math.sign(f.lado) * lim01((P * Math.abs(f.lado) - .9) / 1);
		a.caimento[i] = caim;
		const u = .35 * lim01(instab / .8) + .3 * lim01((vRel - 1.3) / .7) * afinamento + .35 * lim01((F - 2) / .6);
		const base = DEFEITOS.mordeduraMaxMm * u;
		const extraCima = DEFEITOS.mordeduraCaimentoMm * Math.abs(caim);
		a.mordeduraMenos[i] = base + (caim > 0 ? extraCima : 0);
		a.mordeduraMais[i] = base + (caim < 0 ? extraCima : 0);
		const o = lim01((.7 - vRel) / .4) * lim01((2.1 - F) / .6) + .5 * lim01(-instab / .8) * lim01((.9 - vRel) / .5) + .6 * desc;
		a.sobreposicaoMenos[i] = lim01(o + (caim < 0 ? .6 * Math.abs(caim) : 0));
		a.sobreposicaoMais[i] = lim01(o + (caim > 0 ? .6 * Math.abs(caim) : 0));
		const p = lim01(porosidadeBase + .5 * lim01((instab - .2) / .6) + .15 * f.cabeca);
		a.porosidade[i] = p;
		const meia = s.larguraMm / 2;
		if (a.gotejamento[i] > .15 && sorteioFixo(i, 1) < .35 * a.gotejamento[i] * passo) a.gotas.push({
			xMm: s.xMm,
			nMm: s.yCentroMm + (sorteioFixo(i, 3) - .5) * .5 * s.larguraMm,
			raioMm: (.5 + .7 * sorteioFixo(i, 2)) * (.6 + .6 * a.gotejamento[i])
		});
		const esperado = Math.max(0, respingoGas * (1 + 1.5 * Math.abs(instab)) + respingoDbcp - 1.15) * DEFEITOS.respingosPorMm * passo;
		for (let k = 0; k < 2; k++) {
			if (sorteioFixo(i, 10 + k) >= esperado - k) continue;
			const lado = sorteioFixo(i, 20 + k) < .5 ? -1 : 1;
			const dist = .5 + 10 * sorteioFixo(i, 30 + k) ** 2;
			a.respingos.push({
				xMm: s.xMm + (sorteioFixo(i, 40 + k) - .5) * passo,
				nMm: s.yCentroMm + lado * (meia + dist),
				raioMm: .2 + .35 * sorteioFixo(i, 50 + k),
				lado,
				distMm: dist
			});
		}
		if (p > .2 && sorteioFixo(i, 60) < .5 * p * passo * 2) {
			const topo = Math.max(.3, s.alturaMm);
			a.poros.push({
				xMm: s.xMm,
				nMm: s.yCentroMm + (sorteioFixo(i, 61) - .5) * .6 * s.larguraMm,
				wMm: -.5 * ctx.espessuraMm * sorteioFixo(i, 62) + .7 * topo * sorteioFixo(i, 63),
				raioMm: .12 + .3 * sorteioFixo(i, 64) * p,
				superficie: p > .5 && sorteioFixo(i, 65) < .3 * p
			});
		}
	}
	if (e.registro) escamas(a, e.registro);
	if (e.eventos) crateras(a, cordao, e.eventos);
	const D = indiceDeformacao(fusao.filter((p) => p.estado !== "sem-cordao"), ctx);
	a.empenoGraus = Math.min(DEFEITOS.empenoMaxGraus, DEFEITOS.empenoPorD * D);
	a.ocorrencias = ocorrencias(a, secoes);
	return a;
}
/** H56: fase das escamas pelo tempo de arco em que a tocha passou por cada fatia (a última passada vale). */
function escamas(a, registro) {
	const passo = a.passoMm;
	const visto = new Uint8Array(a.n);
	for (let k = 0; k + 1 < registro.length; k++) {
		const p = registro[k];
		const q = registro[k + 1];
		const dt = q.tempoArcoMs - p.tempoArcoMs;
		if (dt <= 0 || q.x === p.x) continue;
		const dir = q.x > p.x ? 1 : -1;
		const i0 = Math.max(0, Math.ceil(Math.min(p.x, q.x) / passo - .5));
		const i1 = Math.min(a.n - 1, Math.floor(Math.max(p.x, q.x) / passo - .5));
		for (let i = i0; i <= i1; i++) {
			const x = (i + .5) * passo;
			const t = p.tempoArcoMs + (x - p.x) / (q.x - p.x) * dt;
			a.escamaFase[i] = t / DEFEITOS.intervaloEscamaMs;
			a.escamaDir[i] = dir;
			visto[i] = 1;
		}
	}
	let ultimo = -1;
	for (let i = 0; i < a.n; i++) if (visto[i]) ultimo = i;
	else if (ultimo >= 0) {
		a.escamaFase[i] = a.escamaFase[ultimo] + (i - ultimo) * passo * a.escamaDir[ultimo] / 1.2;
		a.escamaDir[i] = a.escamaDir[ultimo];
	}
	let primeiro = -1;
	for (let i = a.n - 1; i >= 0; i--) if (visto[i]) primeiro = i;
	else if (primeiro >= 0 && a.escamaDir[i] === 0) {
		a.escamaFase[i] = a.escamaFase[primeiro] - (primeiro - i) * passo * a.escamaDir[primeiro] / 1.2;
		a.escamaDir[i] = a.escamaDir[primeiro];
	}
}
/**
* H55: cada fim de passe deixa uma cratera, a menos que a tocha tenha ficado
* parada ali um instante antes de fechar o arco, ou que outro passe tenha
* coberto o lugar depois.
*/
function crateras(a, cordao, eventos) {
	const pontos = [];
	for (const ev of eventos) {
		if (ev.tipo === "ajustes" || ev.tipo === "posicao") continue;
		if (ev.tipo === "inicio") pontos.length = 0;
		pontos.push({
			t: ev.t,
			x: ev.x
		});
		if (ev.tipo !== "fim") continue;
		const fim = ev;
		let parado = 0;
		let dir = 0;
		for (let k = pontos.length - 1; k > 0; k--) {
			const p = pontos[k - 1];
			const q = pontos[k];
			if (q.t < fim.t - 600) break;
			if (dir === 0 && Math.abs(q.x - p.x) > .3) dir = Math.sign(q.x - p.x);
			if (Math.abs(p.x - fim.x) <= .5 && Math.abs(q.x - fim.x) <= .5) parado += q.t - Math.max(p.t, fim.t - 600);
		}
		pontos.length = 0;
		const c0 = lim01(1 - parado / DEFEITOS.enchimentoCrateraMs);
		if (c0 <= 0) continue;
		const i = cordao.indiceEm(fim.x);
		const s = cordao.secao(i);
		if (s.larguraMm < 1.5 || s.tUltimoDepositoMs > fim.t + 1) continue;
		const xc = fim.x - (dir || 1) * .8;
		const r = Math.ceil(3 / a.passoMm);
		for (let k = Math.max(0, i - r); k <= Math.min(a.n - 1, i + r); k++) {
			const x = (k + .5) * a.passoMm;
			a.cratera[k] = Math.max(a.cratera[k], c0 * Math.exp(-(((x - xc) / 1.2) ** 2)));
		}
	}
}
function ocorrencias(a, secoes) {
	const lista = [];
	const trechos = (tipo, valor, limiar, unidade, minimoMm = 1) => {
		let ini = -1;
		let maior = 0;
		for (let i = 0; i <= a.n; i++) {
			const v = i < a.n && secoes[i].larguraMm >= 1 ? valor(i) : 0;
			if (v > limiar) {
				if (ini < 0) {
					ini = i;
					maior = 0;
				}
				maior = Math.max(maior, v);
			} else if (ini >= 0) {
				if ((i - ini) * a.passoMm >= minimoMm) lista.push({
					tipo,
					inicioMm: ini * a.passoMm,
					fimMm: i * a.passoMm,
					valor: maior,
					limiar,
					unidade
				});
				ini = -1;
			}
		}
	};
	trechos("escorrimento", (i) => a.rolos[i], .25, "índice 0–1");
	trechos("gotejamento", (i) => a.gotejamento[i], .2, "índice 0–1");
	trechos("caimento", (i) => Math.abs(a.caimento[i]), .3, "índice 0–1");
	trechos("mordedura", (i) => Math.max(a.mordeduraMenos[i], a.mordeduraMais[i]), a.limiteMordeduraMm, "mm");
	trechos("sobreposicao", (i) => Math.max(a.sobreposicaoMenos[i], a.sobreposicaoMais[i]), .3, "índice 0–1");
	trechos("porosidade", (i) => a.porosidade[i], .3, "índice 0–1");
	trechos("cratera", (i) => a.cratera[i], .3, "índice 0–1", .5);
	const comprimento = secoes.filter((s) => s.larguraMm >= 1).length * a.passoMm;
	const por10 = comprimento > 0 ? a.respingos.length / comprimento * 10 : 0;
	if (por10 > 2) {
		const xs = a.respingos.map((r) => r.xMm);
		lista.push({
			tipo: "respingos",
			inicioMm: Math.min(...xs),
			fimMm: Math.max(...xs),
			valor: por10,
			limiar: 2,
			unidade: "por 10 mm"
		});
	}
	return lista.sort((x, y) => x.inicioMm - y.inicioMm);
}
/** Respingos presos por 10 mm de cordão. */
function respingosPor10mm(a, comprimentoComCordaoMm) {
	return comprimentoComCordaoMm > 0 ? a.respingos.length / comprimentoComCordaoMm * 10 : 0;
}
/**
* Nota de superfície da fatia (0 a 1, H50–H55): cai aos poucos com cada
* defeito visível; 1 sem defeitos.
*/
function notaSuperficie(a, i) {
	const mm = Math.max(a.mordeduraMenos[i], a.mordeduraMais[i]);
	const L = a.limiteMordeduraMm;
	return lim01(1 - (lim01((mm - .5 * L) / L) + Math.max(a.sobreposicaoMenos[i], a.sobreposicaoMais[i]) + .7 * a.rolos[i] + .8 * a.gotejamento[i] + .6 * a.cratera[i] + .5 * lim01((Math.abs(a.caimento[i]) - .3) / .7)));
}
/** Quanto da fusão prevista vale na fatia (H53, H57): poros e sobreposição tiram integridade. */
function fatorIntegridade(a, i) {
	return (1 - .6 * a.porosidade[i]) * (1 - .4 * Math.max(a.sobreposicaoMenos[i], a.sobreposicaoMais[i]));
}
//#endregion
//#region src/pontuacao/regras.ts
var VERSAO_PONTUACAO = "pontuacao-v9";
/** Nota máxima (cada ponto de peso vale ESCALA ÷ 100). */
var ESCALA_PONTUACAO = 1e3;
/**
* Faixas de tolerância da nota graduada (critérios DO JOGO, em mm ou índice):
* fora da faixa pedida, a nota daquela posição cai linearmente até zero
* nessa distância. Inspirado na ideia de níveis de aceitação por desvio
* (ex.: ISO 5817), sem reproduzir os limites de nenhuma norma.
*/
var TOLERANCIAS = {
	/** Largura fora da faixa do desenho: zero a 1,5 mm além do limite. */
	larguraMm: 1.5,
	/** Reforço acima do máximo: zero a 1,0 mm além. */
	reforcoMm: 1,
	/** Junta não enchida (superfície do metal abaixo da face): zero a 1,0 mm abaixo. */
	faltaEnchimentoMm: 1,
	/** Centro do cordão fora do alinhamento: zero a 1,0 mm além. */
	alinhamentoMm: 1,
	/** Índice de fusão abaixo de 1: zero em 0,6. */
	fusaoMinima: .6,
	/** Reinícios de arco no trecho até zerar a parte de reinícios. */
	reinicios: 3,
	/** Metal no trecho ÷ metal na peça: zero em 80 %. */
	aproveitamentoMinimo: .8,
	/** Variação da largura (desvio ÷ média) que zera a regularidade. */
	variacaoMaxima: .2,
	/** Índice de deformação D que zera o controle térmico. */
	deformacaoMaxima: 2,
	/** Fração do tempo de arco sobre a junta abaixo da qual essa parte da Execução zera. */
	tempoUtilMinimo: .7,
	/** Nota mínima de uma posição com fusão excessiva (antes de perfurar). */
	excessivaMinima: 0
};
/**
* H88: modo Fácil. As faixas em que a nota cai até zero ficam duas vezes mais
* largas (e a variação aceita na largura, 50 % maior); o Difícil usa TOLERANCIAS.
*/
var TOLERANCIAS_FACIL = {
	larguraMm: 3,
	reforcoMm: 2,
	faltaEnchimentoMm: 2,
	alinhamentoMm: 2,
	fusaoMinima: .4,
	reinicios: 6,
	aproveitamentoMinimo: .6,
	variacaoMaxima: .3,
	deformacaoMaxima: 3,
	tempoUtilMinimo: .5,
	excessivaMinima: .5
};
/** Tolerâncias da nota no modo escolhido (H88). */
function toleranciasDe(d) {
	return d === "aprendiz" ? TOLERANCIAS_FACIL : TOLERANCIAS;
}
var NOME_CATEGORIA = {
	integridade: "Fusão prevista (integridade)",
	desenho: "Geometria do cordão",
	regularidade: "Regularidade da largura",
	deformacao: "Controle térmico",
	eficiencia: "Execução"
};
var PESOS_PADRAO = {
	integridade: 40,
	desenho: 25,
	regularidade: 15,
	deformacao: 10,
	eficiencia: 10
};
var limitar = (v) => Math.min(1, Math.max(0, v));
/** Linear: 1 até `limite`, 0 a `faixa` além dele. */
var cair = (excesso, faixa) => limitar(1 - Math.max(0, excesso) / faixa);
var fmt1 = (v) => v.toLocaleString("pt-BR", {
	minimumFractionDigits: 1,
	maximumFractionDigits: 1
});
var fmtPct = (v) => v.toLocaleString("pt-BR", {
	style: "percent",
	maximumFractionDigits: 0
});
/** Maior sequência contínua (mm) de posições que satisfazem o critério. */
function maiorSequencia(pontos, criterio, passoMm) {
	let maior = 0;
	let atual = 0;
	for (const p of pontos) {
		atual = criterio(p) ? atual + 1 : 0;
		maior = Math.max(maior, atual);
	}
	return maior * passoMm;
}
function agruparProblemas(pontos, passoMm) {
	const trechos = [];
	for (const p of pontos) {
		if (p.estado === "adequada") continue;
		const ultimo = trechos[trechos.length - 1];
		if (ultimo && ultimo.estado === p.estado && Math.abs(ultimo.fimMm - (p.xMm - passoMm / 2)) < 1e-6) ultimo.fimMm = p.xMm + passoMm / 2;
		else trechos.push({
			inicioMm: p.xMm - passoMm / 2,
			fimMm: p.xMm + passoMm / 2,
			estado: p.estado,
			descricao: DESCRICAO_ESTADO[p.estado]
		});
	}
	return trechos.filter((t) => t.fimMm - t.inicioMm >= 1);
}
function pontuar(e, pesos = PESOS_PADRAO) {
	const { missao, contexto, cordao } = e;
	const req = requisitosEfetivos(missao, e.dificuldade);
	const passo = cordao.passoMm;
	const { inicioMm: x0, fimMm: x1 } = missao.trecho;
	const a0 = x0 + 2;
	const a1 = x1 - 2;
	const T = toleranciasDe(e.dificuldade);
	const fusao = analisarFusao(cordao, e.percurso, contexto);
	const defeitos = analisarDefeitos({
		cordao,
		percurso: e.percurso,
		contexto,
		eventos: e.eventos,
		fusao
	});
	const secoes = Array.from({ length: cordao.nPosicoes }, (_, i) => cordao.secao(i));
	const noTrecho = (x) => x >= x0 && x <= x1;
	const avaliado = (x) => x >= a0 && x <= a1;
	const fAvaliado = fusao.filter((p) => avaliado(p.xMm));
	const comCordao = secoes.filter((s) => avaliado(s.xMm)).filter((s) => s.larguraMm >= 1);
	const n = Math.max(1, fAvaliado.length);
	const media = (v) => v.length ? v.reduce((a, b) => a + b, 0) / v.length : 0;
	const fracaoIntegra = fAvaliado.filter((p) => p.estado === "adequada").length / n;
	const contagem = (estado) => fAvaliado.filter((p) => p.estado === estado).length / n;
	const notaPosicao = (p) => {
		if (p.estado === "adequada") return 1;
		if (p.estado === "falta") return limitar((p.indice - T.fusaoMinima) / (FUSAO.minimoAdequado - T.fusaoMinima));
		if (p.estado === "excessiva") return T.excessivaMinima + (1 - T.excessivaMinima) * limitar((FUSAO.perfuracao - p.indice) / (FUSAO.perfuracao - FUSAO.maximoAdequado));
		if (p.estado === "enchimento") return .5 * limitar(cordao.secao(cordao.indiceEm(p.xMm)).enchimento ?? 0);
		return 0;
	};
	const notaFusao = fAvaliado.length ? media(fAvaliado.map((p) => notaPosicao(p) * fatorIntegridade(defeitos, cordao.indiceEm(p.xMm)))) : 0;
	const noTrechoSecoes = secoes.filter((s) => noTrecho(s.xMm));
	const extensao = noTrechoSecoes.filter((s) => s.larguraMm >= 1).length / Math.max(1, noTrechoSecoes.length);
	const nota = (f) => comCordao.length ? media(comCordao.map(f)) : 0;
	const largura = nota((s) => cair(Math.max(req.larguraMinMm - s.larguraMm, s.larguraMm - req.larguraMaxMm), T.larguraMm));
	const reforco = nota((s) => s.alturaMm < 0 ? cair(-s.alturaMm, T.faltaEnchimentoMm) : cair(s.alturaMm - req.reforcoMaxMm, T.reforcoMm));
	const alinhamento = nota((s) => cair(Math.abs(s.yCentroMm) - req.alinhamentoMm, T.alinhamentoMm));
	const respingos10 = respingosPor10mm(defeitos, secoes.filter((s) => s.larguraMm >= 1).length * passo);
	const superficie = limitar(nota((s) => notaSuperficie(defeitos, cordao.indiceEm(s.xMm))) - Math.min(.3, .05 * Math.max(0, respingos10 - 2)));
	const fracaoDesenho = (7 * extensao + 8 * largura + 5 * reforco + 5 * alinhamento + 5 * superficie) / 30;
	const estrita = (f) => comCordao.length ? comCordao.filter(f).length / comCordao.length : 0;
	const larguraDentro = estrita((s) => s.larguraMm >= req.larguraMinMm && s.larguraMm <= req.larguraMaxMm);
	const larguras = comCordao.map((s) => s.larguraMm);
	const larguraMedia = media(larguras);
	const cv = larguras.length >= 10 ? Math.sqrt(larguras.reduce((s, w) => s + (w - larguraMedia) ** 2, 0) / larguras.length) / larguraMedia : 1;
	const fracaoRegularidade = larguras.length >= 10 ? limitar((T.variacaoMaxima - cv) / (T.variacaoMaxima - .03)) : 0;
	const alturaMedia = media(comCordao.map((c) => c.alturaMm));
	const deformacao = indiceDeformacao(fAvaliado, contexto);
	const fracaoDeformacao = fAvaliado.some((p) => p.estado !== "sem-cordao") ? limitar((T.deformacaoMaxima - deformacao) / (T.deformacaoMaxima - 1)) : 0;
	const rendimento = GASES[contexto.gas].rendimento;
	const tempoUtil = e.tempoArcoMs > 0 ? e.percurso.pertoDaJuntaEntre(x0 - 5, x1 + 5) / e.tempoArcoMs : 0;
	const aberturasPlanejadas = Math.max(1, missao.aberturasPlanejadas ?? 1);
	const reinicios = Math.max(0, (e.aberturasDeArco ?? 1) - aberturasPlanejadas);
	const volumes = cordao.copiaDosVolumes();
	let metalTrecho = 0;
	let metalTotal = 0;
	for (let i = 0; i < volumes.length; i++) {
		metalTotal += volumes[i];
		if (noTrecho((i + .5) * passo)) metalTrecho += volumes[i];
	}
	metalTotal += cordao.volumeSolto();
	const aproveitamento = metalTotal > 0 ? metalTrecho / metalTotal : 0;
	const fracaoEficiencia = .4 * limitar((tempoUtil - T.tempoUtilMinimo) / (1 - T.tempoUtilMinimo)) + .3 * cair(reinicios, T.reinicios) + .3 * limitar((aproveitamento - T.aproveitamentoMinimo) / (1 - T.aproveitamentoMinimo));
	const perfuracaoMm = maiorSequencia(fAvaliado, (p) => p.estado === "perfuracao", passo);
	const semCordaoMm = maiorSequencia(fAvaliado, (p) => p.estado === "sem-cordao", passo);
	const essenciais = [
		{
			id: "E1",
			descricao: `Integridade prevista em pelo menos ${fmtPct(req.integridadeMinima)} do trecho avaliado`,
			cumprida: fracaoIntegra >= req.integridadeMinima,
			justificativa: `Fusão adequada prevista em ${fmtPct(fracaoIntegra)} do trecho.`
		},
		{
			id: "E2",
			descricao: "Evitar perfuração",
			cumprida: perfuracaoMm < 1,
			justificativa: perfuracaoMm < 1 ? "Sem perfuração prevista." : `Perfuração prevista em até ${fmt1(perfuracaoMm)} mm contínuos.`
		},
		{
			id: "E3",
			descricao: "Cordão contínuo no trecho exigido",
			cumprida: semCordaoMm < 1,
			justificativa: semCordaoMm < 1 ? "Sem interrupções." : `Trecho sem cordão de até ${fmt1(semCordaoMm)} mm.`
		}
	];
	if (MATERIAIS[contexto.material].exigeLimpeza) essenciais.push({
		id: "E4",
		descricao: "Óxido removido antes de soldar",
		cumprida: contexto.oxidoRemovido,
		justificativa: contexto.oxidoRemovido ? "Limpeza feita na preparação." : "A limpeza do óxido não foi feita na preparação."
	});
	const aprovada = essenciais.every((c) => c.cumprida);
	const fator = ESCALA_PONTUACAO / 100;
	const pontos = (c, fracao) => Math.round(pesos[c] * fator * fracao);
	const maximo = (c) => pesos[c] * fator;
	const categorias = [
		{
			id: "integridade",
			nome: NOME_CATEGORIA.integridade,
			pontos: pontos("integridade", notaFusao),
			maximo: maximo("integridade"),
			explicacao: `Nota média de fusão ${fmtPct(notaFusao)}; fusão adequada em ${fmtPct(fracaoIntegra)} do trecho avaliado. Falta de fusão: ${fmtPct(contagem("falta"))}; excessiva: ${fmtPct(contagem("excessiva"))}; perfuração: ${fmtPct(contagem("perfuracao"))}; borda descoberta: ${fmtPct(contagem("borda"))}; junta não enchida: ${fmtPct(contagem("enchimento"))}; sem cordão: ${fmtPct(contagem("sem-cordao"))}. Resultado sintético do modelo.`,
			detalhes: [{
				rotulo: "Nota de fusão",
				valor: fmtPct(notaFusao)
			}, {
				rotulo: "Fração íntegra",
				valor: fmtPct(fracaoIntegra)
			}]
		},
		{
			id: "desenho",
			nome: NOME_CATEGORIA.desenho,
			pontos: pontos("desenho", fracaoDesenho),
			maximo: maximo("desenho"),
			explicacao: `Extensão ${fmtPct(extensao)}. Largura (${fmt1(req.larguraMinMm)}–${fmt1(req.larguraMaxMm)} mm): nota ${fmtPct(largura)}, ${fmtPct(larguraDentro)} dentro. Reforço até ${fmt1(req.reforcoMaxMm)} mm (sem afundar abaixo da face): nota ${fmtPct(reforco)}. Centro a até ${fmt1(req.alinhamentoMm)} mm da junta: nota ${fmtPct(alinhamento)}. Superfície (defeitos visíveis previstos): nota ${fmtPct(superficie)}.`,
			detalhes: [
				{
					rotulo: "Extensão",
					valor: fmtPct(extensao)
				},
				{
					rotulo: "Largura",
					valor: fmtPct(largura)
				},
				{
					rotulo: "Reforço",
					valor: fmtPct(reforco)
				},
				{
					rotulo: "Alinhamento",
					valor: fmtPct(alinhamento)
				},
				{
					rotulo: "Superfície",
					valor: fmtPct(superficie)
				}
			]
		},
		{
			id: "regularidade",
			nome: NOME_CATEGORIA.regularidade,
			pontos: pontos("regularidade", fracaoRegularidade),
			maximo: maximo("regularidade"),
			explicacao: larguras.length >= 10 ? `A largura variou ${fmtPct(cv)} (média ${fmt1(larguraMedia)} mm). Até 3 % ganha tudo; 20 % ou mais, nada.` : "Cordão curto demais para medir a regularidade.",
			detalhes: [{
				rotulo: "Variação da largura",
				valor: larguras.length >= 10 ? fmtPct(cv) : "—"
			}]
		},
		{
			id: "deformacao",
			nome: NOME_CATEGORIA.deformacao,
			pontos: pontos("deformacao", fracaoDeformacao),
			maximo: maximo("deformacao"),
			explicacao: `Índice de deformação ${fmt1(deformacao)} (até 1 sem perda; 2 ou mais perde tudo). ${MATERIAIS[contexto.material].nome}: fator ${fmt1(MATERIAIS[contexto.material].fatorDeformacao)}.`,
			detalhes: [{
				rotulo: "Índice D",
				valor: fmt1(deformacao)
			}]
		},
		{
			id: "eficiencia",
			nome: NOME_CATEGORIA.eficiencia,
			pontos: pontos("eficiencia", fracaoEficiencia),
			maximo: maximo("eficiencia"),
			explicacao: `${fmtPct(tempoUtil)} do tempo de arco sobre a junta; ${reinicios} reinício(s) além dos passes previstos; ${fmtPct(aproveitamento)} do metal dentro do trecho pedido.`,
			detalhes: [
				{
					rotulo: "Arco sobre a junta",
					valor: fmtPct(tempoUtil)
				},
				{
					rotulo: "Reinícios além dos passes previstos",
					valor: String(reinicios)
				},
				{
					rotulo: "Metal no trecho",
					valor: fmtPct(aproveitamento)
				}
			]
		}
	];
	const penalidades = [];
	return {
		versao: VERSAO_PONTUACAO,
		pesos: { ...pesos },
		total: categorias.reduce((s, c) => s + c.pontos, 0),
		aprovada,
		categorias,
		essenciais,
		penalidades,
		problemas: agruparProblemas(fusao.filter((p) => noTrecho(p.xMm)), passo),
		medidas: {
			fracaoIntegra,
			larguraMediaMm: larguraMedia,
			alturaMediaMm: alturaMedia,
			cvLargura: larguras.length >= 10 ? cv : NaN,
			deformacao,
			rendimento,
			fracaoTempoUtil: tempoUtil,
			notaFusao,
			reiniciosArco: reinicios,
			aproveitamentoMetal: aproveitamento
		}
	};
}
//#endregion
//#region src/rede/contrato.ts
var PROTOCOLO_REDE = "soldagem-rede-1.7.1";
var MODELO_REDE = VERSAO_PONTUACAO;
var MISSOES_REDE = MISSOES.filter((m) => m.material === "aco-carbono");
function configuracaoRede(c) {
	const missao = MISSOES_REDE.find((m) => m.id === c.missaoId);
	if (c.processo !== "mig" || !missao || !["aprendiz", "profissional"].includes(c.dificuldade)) throw new Error("Missão ou dificuldade indisponível nesta versão do x1.");
	const preparo = {
		...preparoPadrao(missao),
		oxidoRemovido: true
	};
	return {
		missao,
		preparo,
		contexto: contextoDaMissao(missao, preparo),
		ajustes: { ...AJUSTES_PADRAO }
	};
}
//#endregion
//#region src/modelo/avaliacao.ts
function estatistica(valores) {
	const n = valores.length;
	const media = valores.reduce((s, v) => s + v, 0) / n;
	const variancia = valores.reduce((s, v) => s + (v - media) ** 2, 0) / n;
	return {
		media,
		min: Math.min(...valores),
		max: Math.max(...valores),
		desvioPadrao: Math.sqrt(variancia)
	};
}
function classificarRegularidade(cv) {
	if (cv <= AVALIACAO.cvMuitoRegular) return "muito regular";
	if (cv <= AVALIACAO.cvRegular) return "regular";
	return "irregular";
}
function classificarAlinhamento(desvioMedioMm) {
	if (desvioMedioMm <= AVALIACAO.desvioCentradoMm) return "centrado";
	if (desvioMedioMm <= AVALIACAO.desvioLeveMm) return "levemente deslocado";
	return "deslocado";
}
function avaliar(cordao) {
	const perfil = Array.from({ length: cordao.nPosicoes }, (_, i) => cordao.secao(i));
	const temCordao = (s) => s.larguraMm >= AVALIACAO.larguraMinimaMm;
	const passo = cordao.passoMm;
	const comCordao = perfil.filter(temCordao);
	const cobrem = comCordao.filter((s) => Math.abs(s.yCentroMm) <= s.larguraMm / 2);
	const base = {
		perfil,
		comprimentoComCordaoMm: comCordao.length * passo,
		fracaoLinhaCoberta: cobrem.length * passo / cordao.comprimentoMm
	};
	if (comCordao.length === 0) return {
		...base,
		medidas: null
	};
	const inicioMm = comCordao[0].xMm - passo / 2 + AVALIACAO.aparaPontasMm;
	const fimMm = comCordao[comCordao.length - 1].xMm + passo / 2 - AVALIACAO.aparaPontasMm;
	if (fimMm - inicioMm < AVALIACAO.comprimentoMinimoMm) return {
		...base,
		medidas: null
	};
	const naRegiao = perfil.filter((s) => s.xMm >= inicioMm && s.xMm <= fimMm);
	const medidos = naRegiao.filter(temCordao);
	if (medidos.length === 0) return {
		...base,
		medidas: null
	};
	let quantidade = 0;
	let fatiasSemCordao = 0;
	naRegiao.forEach((s, k) => {
		if (temCordao(s)) return;
		fatiasSemCordao++;
		if (k === 0 || temCordao(naRegiao[k - 1])) quantidade++;
	});
	const alvo = areaAlvo();
	const noAlvo = naRegiao.filter((s) => s.areaMm2 >= alvo.minMm2 && s.areaMm2 <= alvo.maxMm2).length;
	const largura = estatistica(medidos.map((s) => s.larguraMm));
	const desvios = medidos.map((s) => Math.abs(s.yCentroMm));
	const desvioMedio = desvios.reduce((a, b) => a + b, 0) / desvios.length;
	const desvioMax = Math.max(...desvios);
	const cvLargura = largura.desvioPadrao / largura.media;
	return {
		...base,
		medidas: {
			regiao: {
				inicioMm,
				fimMm
			},
			largura,
			altura: estatistica(medidos.map((s) => s.alturaMm)),
			area: estatistica(medidos.map((s) => s.areaMm2)),
			cvLargura,
			regularidade: classificarRegularidade(cvLargura),
			desvioCentro: {
				medioAbsMm: desvioMedio,
				maxAbsMm: desvioMax,
				xDoMaximoMm: medidos[desvios.indexOf(desvioMax)].xMm
			},
			alinhamento: classificarAlinhamento(desvioMedio),
			interrupcoes: {
				quantidade,
				comprimentoMm: fatiasSemCordao * passo
			},
			fracaoNoAlvo: noAlvo / naRegiao.length
		}
	};
}
//#endregion
//#region src/modelo/cordao.ts
/**
* Hipótese H3: a seção transversal do cordão é um "domo" parabólico com
* altura = razão × largura. A área de um segmento parabólico é
* (2/3)·largura·altura, logo área = (2/3)·razão·largura².
* A razão vem da tensão (H9); sem informação, usa a de referência.
*/
function larguraPelaArea(areaMm2, razao = MODELO.razaoAlturaLargura) {
	return areaMm2 > 0 ? Math.sqrt(areaMm2 / (2 / 3 * razao)) : 0;
}
/** H44: quanto a largura oscila com o arco totalmente instável, e o viés curto/longo. */
var AMPLITUDE_INSTABILIDADE = .28;
var VIES_INSTABILIDADE = .1;
/**
* Padrão fixo e suave entre −1 e 1 ao longo da junta (H44). É o mesmo em toda
* tentativa, então o replay e qualquer taxa de quadros dão o mesmo cordão.
*/
function padraoIrregular(xMm) {
	const v = Math.sin(2 * Math.PI * xMm / 7.3) + .6 * Math.sin(2 * Math.PI * xMm / 3.1 + 1.3) + .4 * Math.sin(2 * Math.PI * xMm / 13.7 + .4);
	return Math.max(-1, Math.min(1, v / 2));
}
/** Cordões soltos guardados no máximo; além disso o metal vai para o mais próximo. */
var MAX_SOLTOS = 12;
/**
* O cordão é guardado como uma lista de "fatias" ao longo da junta.
* Cada fatia acumula o volume de metal que recebeu. Dividindo o volume pelo
* comprimento da fatia obtemos a área da seção — é só balanço de massa (H2).
*/
var Cordao = class Cordao {
	comprimentoMm;
	sigmaMm;
	forma;
	solto;
	passoMm;
	nPosicoes;
	volumes;
	/** Soma de volume × y, para achar o centro do cordão em cada fatia. */
	momentosY;
	/** Soma de volume × (y² + σ²): dá o espalhamento lateral da tocha (H39). */
	momentosY2;
	/** Soma de volume × instabilidade do arco (H44). */
	momentosInstab;
	/** Soma de volume × razão altura/largura, para a forma média em cada fatia. */
	momentosRazao;
	/** Somas de volume × componentes da gravidade (H50). */
	momentosCabeca;
	momentosLado;
	momentosDescida;
	tUltimo;
	nucleo;
	raio;
	raioRecente;
	/**
	* H58: cordões soltos — metal que caiu longe da junta e longe do cordão que
	* já estava ali (outro ponto de solda na chapa). Cada um tem a própria
	* forma (domo sobre a superfície) e não entra na seção da junta.
	*/
	soltos = [];
	/** Centro lateral de referência de um cordão solto (onde começou). */
	yReferencia = 0;
	constructor(comprimentoMm = PECA.comprimentoMm, passoMm = MODELO.passoMm, sigmaMm = MODELO.sigmaPocaMm, forma = null, solto = false) {
		this.comprimentoMm = comprimentoMm;
		this.sigmaMm = sigmaMm;
		this.forma = forma;
		this.solto = solto;
		this.passoMm = passoMm;
		this.nPosicoes = Math.ceil(comprimentoMm / passoMm);
		this.volumes = new Float64Array(this.nPosicoes);
		this.momentosY = new Float64Array(this.nPosicoes);
		this.momentosY2 = new Float64Array(this.nPosicoes);
		this.momentosInstab = new Float64Array(this.nPosicoes);
		this.momentosRazao = new Float64Array(this.nPosicoes);
		this.momentosCabeca = new Float64Array(this.nPosicoes);
		this.momentosLado = new Float64Array(this.nPosicoes);
		this.momentosDescida = new Float64Array(this.nPosicoes);
		this.tUltimo = new Float64Array(this.nPosicoes).fill(-Infinity);
		this.raio = Math.ceil(3 * sigmaMm / passoMm);
		this.nucleo = new Float64Array(2 * this.raio + 1);
		for (let k = -this.raio; k <= this.raio; k++) this.nucleo[k + this.raio] = Math.exp(-.5 * (k * passoMm / sigmaMm) ** 2);
		this.raioRecente = Math.max(1, Math.round(sigmaMm / passoMm));
	}
	indiceEm(xMm) {
		return Math.min(this.nPosicoes - 1, Math.max(0, Math.floor(xMm / this.passoMm)));
	}
	/**
	* Coloca um volume de metal em (x, y), com a forma de seção dada pela razão
	* altura/largura. Nada se perde: o núcleo é renormalizado nas bordas.
	* `sigmaLateralMm` é a oscilação escolhida na bancada (H39); a feita à mão
	* já aparece na variação de y entre depósitos.
	*/
	depositar(xMm, yMm, volumeMm3, tMs, razao = MODELO.razaoAlturaLargura, sigmaLateralMm = 0, instabilidade = 0, g = null) {
		if (volumeMm3 <= 0) return;
		if (!this.solto && !this.daJunta(xMm, yMm)) {
			this.soltoPara(xMm, yMm).depositar(xMm, yMm, volumeMm3, tMs, razao, sigmaLateralMm, instabilidade, g);
			return;
		}
		const centro = this.indiceEm(xMm);
		const ini = Math.max(0, centro - this.raio);
		const fim = Math.min(this.nPosicoes - 1, centro + this.raio);
		let soma = 0;
		for (let i = ini; i <= fim; i++) soma += this.nucleo[i - centro + this.raio];
		for (let i = ini; i <= fim; i++) {
			const dv = volumeMm3 * this.nucleo[i - centro + this.raio] / soma;
			this.volumes[i] += dv;
			this.momentosY[i] += dv * yMm;
			this.momentosY2[i] += dv * (yMm * yMm + sigmaLateralMm * sigmaLateralMm);
			this.momentosInstab[i] += dv * instabilidade;
			this.momentosRazao[i] += dv * razao;
			if (g) {
				this.momentosCabeca[i] += dv * g.cabeca;
				this.momentosLado[i] += dv * g.lado;
				this.momentosDescida[i] += dv * g.descida;
			}
			if (Math.abs(i - centro) <= this.raioRecente && tMs > this.tUltimo[i]) this.tUltimo[i] = tMs;
		}
	}
	secao(i) {
		const volume = this.volumes[i];
		const area = volume / this.passoMm;
		const razao = volume > 0 ? this.momentosRazao[i] / volume : MODELO.razaoAlturaLargura;
		const largura0 = larguraPelaArea(area, razao);
		const yCentro = volume > 0 ? this.momentosY[i] / volume : 0;
		const variancia = volume > 0 ? Math.max(0, this.momentosY2[i] / volume - yCentro * yCentro) : 0;
		const espalhamento = variancia > 1e-9 ? Math.sqrt(variancia) : 0;
		const xMm = (i + .5) * this.passoMm;
		const instab = volume > 0 ? this.momentosInstab[i] / volume : 0;
		const fator = instab !== 0 ? Math.max(.5, 1 + AMPLITUDE_INSTABILIDADE * Math.abs(instab) * padraoIrregular(xMm) + VIES_INSTABILIDADE * instab) : 1;
		const largura = (espalhamento > 0 ? Math.sqrt(largura0 * largura0 + 12 * variancia) : largura0) * fator;
		const altura = largura > 0 ? largura0 * largura0 * razao / largura : 0;
		const base = {
			xMm,
			areaMm2: area,
			larguraMm: largura,
			alturaMm: altura,
			razaoAlturaLargura: largura > 0 ? altura / largura : razao,
			yCentroMm: yCentro,
			espalhamentoMm: espalhamento,
			larguraSemOscilacaoMm: largura0 * fator,
			instabilidade: instab,
			tUltimoDepositoMs: this.tUltimo[i]
		};
		return this.forma ? secaoNaJunta(base, this.forma.junta, this.forma.dimensoes, razao) : base;
	}
	/** Centro lateral do metal na fatia de x, ou null se ela ainda não tem metal. */
	centroEm(xMm) {
		const i = this.indiceEm(xMm);
		const v = this.volumes[i];
		return v > 1e-9 ? this.momentosY[i] / v : null;
	}
	/** Distância lateral até onde um depósito ainda continua o cordão já existente na fatia de x. */
	alcanceEm(xMm) {
		const i = this.indiceEm(xMm);
		const v = this.volumes[i];
		if (v <= 1e-9) return 0;
		const c = this.momentosY[i] / v;
		const largura = Math.sqrt(larguraPelaArea(v / this.passoMm, this.momentosRazao[i] / v) ** 2 + 12 * Math.max(0, this.momentosY2[i] / v - c * c));
		return Math.max(5, .75 * largura);
	}
	/** H58: o depósito em (x, y) é do cordão da junta? Perto da junta, ou continuando o cordão que já está ali. */
	daJunta(xMm, yMm) {
		if (Math.abs(yMm) <= 8) return true;
		const c = this.centroEm(xMm);
		return c !== null && Math.abs(yMm - c) <= this.alcanceEm(xMm);
	}
	/** Cordão solto que recebe o depósito: o que já passa perto, ou um novo. */
	soltoPara(xMm, yMm) {
		let melhor = null;
		let menor = Infinity;
		for (const s of this.soltos) {
			const c = s.centroEm(xMm);
			const d = Math.abs(yMm - (c ?? s.yReferencia));
			if (d <= (c === null ? 5 : s.alcanceEm(xMm)) && d < menor) {
				menor = d;
				melhor = s;
			}
		}
		if (melhor) return melhor;
		if (this.soltos.length >= MAX_SOLTOS) return this.soltos.reduce((a, b) => Math.abs(b.yReferencia - yMm) < Math.abs(a.yReferencia - yMm) ? b : a);
		const novo = new Cordao(this.comprimentoMm, this.passoMm, this.sigmaMm, null, true);
		novo.yReferencia = yMm;
		this.soltos.push(novo);
		return novo;
	}
	/** Metal dos cordões soltos (mm³, H58): fora da seção da junta. */
	volumeSolto() {
		return this.soltos.reduce((t, s) => t + s.volumeTotal(), 0);
	}
	/** Gravidade e arco médios na fatia i, ponderados pelo metal (H50); zeros sem metal. */
	fisica(i) {
		const v = this.volumes[i];
		if (v <= 0) return {
			cabeca: 0,
			lado: 0,
			descida: 0,
			instabilidade: 0
		};
		return {
			cabeca: this.momentosCabeca[i] / v,
			lado: this.momentosLado[i] / v,
			descida: this.momentosDescida[i] / v,
			instabilidade: this.momentosInstab[i] / v
		};
	}
	/** Quantos mm da junta têm cordão mais largo que o limiar. */
	comprimentoComMaterial(larguraMinMm = 1) {
		let n = 0;
		for (let i = 0; i < this.nPosicoes; i++) if (this.secao(i).larguraMm >= larguraMinMm) n++;
		return n * this.passoMm;
	}
	/** Todo o metal depositado: o do cordão da junta e o dos cordões soltos (H58). */
	volumeTotal() {
		let v = 0;
		for (let i = 0; i < this.nPosicoes; i++) v += this.volumes[i];
		return v + this.volumeSolto();
	}
	/** Volumes por fatia do cordão da junta (sem os soltos). */
	copiaDosVolumes() {
		return this.volumes.slice();
	}
};
//#endregion
//#region src/modelo/movimento.ts
/**
* Lê o percurso da tocha na região avaliada e mede a velocidade efetiva por
* trecho. Devolve null se a avaliação não tem região (nada a medir).
*/
function analisarMovimento(percurso, av) {
	const m = av.medidas;
	if (!m) return null;
	const trechos = [];
	const { inicioMm, fimMm } = m.regiao;
	for (let a = inicioMm; fimMm - a >= EXPLICACAO.trechoMm / 2; a += EXPLICACAO.trechoMm) {
		const b = Math.min(fimMm, a + EXPLICACAO.trechoMm);
		const permanenciaMs = percurso.permanenciaEntre(a, b);
		const fatias = av.perfil.filter((s) => s.xMm >= a && s.xMm < b);
		trechos.push({
			inicioMm: a,
			fimMm: b,
			permanenciaMs,
			velocidadeMms: permanenciaMs > 0 ? (b - a) / (permanenciaMs / 1e3) : null,
			larguraMediaMm: fatias.reduce((s, f) => s + f.larguraMm, 0) / Math.max(1, fatias.length)
		});
	}
	const comArco = trechos.filter((t) => t.velocidadeMms !== null);
	if (comArco.length === 0) return null;
	const v = comArco.map((t) => t.velocidadeMms);
	const media = v.reduce((s, x) => s + x, 0) / v.length;
	const desvioPadrao = Math.sqrt(v.reduce((s, x) => s + (x - media) ** 2, 0) / v.length);
	const ordenadas = [...v].sort((a, b) => a - b);
	const mediana = ordenadas[Math.floor(ordenadas.length / 2)];
	const tempoTotalMs = comArco.reduce((s, t) => s + t.permanenciaMs, 0);
	return {
		trechos,
		velocidadeMediaMms: comArco.reduce((s, t) => s + (t.fimMm - t.inicioMm), 0) / (tempoTotalMs / 1e3),
		velocidade: {
			media,
			min: Math.min(...v),
			max: Math.max(...v),
			desvioPadrao
		},
		cvVelocidade: desvioPadrao / media,
		pausas: comArco.filter((t) => t.velocidadeMms < EXPLICACAO.pausaFracaoMediana * mediana)
	};
}
/**
* O que aconteceu em cada posição da junta enquanto o arco estava aberto:
* tempo de permanência (H20), aporte relativo (H31) e aporte efetivo, que já
* inclui o aquecimento acumulado (H32). É alimentado pela mesma integração
* que deposita o metal, então não depende dos quadros.
*/
var Percurso = class {
	comprimentoMm;
	passoMm;
	nPosicoes;
	permanenciaMs;
	/** Tempo com a tocha a até DISTANCIA_JUNTA_MM da linha da junta. */
	pertoDaJuntaMs;
	/** Σ potência × dt (s). */
	aportes;
	/** Σ potência × ∫(1 + e·T) dt (s). */
	aportesEfetivos;
	constructor(comprimentoMm = PECA.comprimentoMm, passoMm = MODELO.passoMm) {
		this.comprimentoMm = comprimentoMm;
		this.passoMm = passoMm;
		this.nPosicoes = Math.ceil(comprimentoMm / passoMm);
		this.permanenciaMs = new Float64Array(this.nPosicoes);
		this.pertoDaJuntaMs = new Float64Array(this.nPosicoes);
		this.aportes = new Float64Array(this.nPosicoes);
		this.aportesEfetivos = new Float64Array(this.nPosicoes);
	}
	registrar(xMm, yMm, duracaoMs, aporte = 0, aporteEfetivo = 0) {
		if (xMm < 0 || xMm > this.comprimentoMm || duracaoMs <= 0) return;
		const i = Math.min(this.nPosicoes - 1, Math.floor(xMm / this.passoMm));
		this.permanenciaMs[i] += duracaoMs;
		if (Math.abs(yMm) <= 10) this.pertoDaJuntaMs[i] += duracaoMs;
		this.aportes[i] += aporte;
		this.aportesEfetivos[i] += aporteEfetivo;
	}
	somaEntre(v, x0Mm, x1Mm) {
		let soma = 0;
		for (let i = 0; i < this.nPosicoes; i++) {
			const x = (i + .5) * this.passoMm;
			if (x >= x0Mm && x < x1Mm) soma += v[i];
		}
		return soma;
	}
	/** Tempo de arco (ms) com a tocha em [x0, x1), contando fatias pelo centro. */
	permanenciaEntre(x0Mm, x1Mm) {
		return this.somaEntre(this.permanenciaMs, x0Mm, x1Mm);
	}
	/** Tempo de arco (ms) em [x0, x1) com a tocha perto da linha da junta. */
	pertoDaJuntaEntre(x0Mm, x1Mm) {
		return this.somaEntre(this.pertoDaJuntaMs, x0Mm, x1Mm);
	}
	total() {
		return this.permanenciaEntre(0, Infinity);
	}
	/** Tempo de arco por fatia (ms), com a tocha em cima dela. */
	copiaDasPermanencias() {
		return this.permanenciaMs.slice();
	}
	copiaDosAportes() {
		return this.aportes.slice();
	}
	copiaDosAportesEfetivos() {
		return this.aportesEfetivos.slice();
	}
};
//#endregion
//#region src/modelo/trajetoria.ts
/**
* O mouse só envia leituras quando se mexe. Se passou muito tempo entre duas
* leituras, a tocha ficou PARADA na primeira posição e só depois se deslocou.
* Hipótese H5: o deslocamento entre duas leituras dura no máximo
* TRAJETORIA.duracaoMaxDeslocamentoMs. Esta função diz quando ele começou.
*/
function inicioDoDeslocamento(a0, a1) {
	return Math.max(a0.t, a1.t - TRAJETORIA.duracaoMaxDeslocamentoMs);
}
/** Posição da tocha no instante t, entre as leituras a0 e a1 (segundo H5). */
function posicaoEntre(a0, a1, t) {
	const tIni = inicioDoDeslocamento(a0, a1);
	if (t <= tIni) return a0;
	if (t >= a1.t) return a1;
	const f = (t - tIni) / (a1.t - tIni);
	return {
		x: a0.x + (a1.x - a0.x) * f,
		y: a0.y + (a1.y - a0.y) * f
	};
}
//#endregion
//#region src/modelo/velocidade.ts
var PARADO = {
	avancoMms: 0,
	lateralMms: 0,
	totalMms: 0
};
/**
* Mede a velocidade a partir das leituras do mouse e dos instantes em que
* elas aconteceram — nunca a partir do número de quadros desenhados.
*
* Usa uma janela de tempo (H6): velocidade = deslocamento na janela / duração
* da janela. Isso funciona igual a 30 ou a 240 quadros por segundo.
*/
var EstimadorVelocidade = class {
	janelaMs;
	amostras = [];
	constructor(janelaMs = VELOCIDADE.janelaMs) {
		this.janelaMs = janelaMs;
	}
	limpar() {
		this.amostras = [];
	}
	adicionar(a) {
		const ultima = this.amostras[this.amostras.length - 1];
		const nova = ultima && a.t < ultima.t ? {
			...a,
			t: ultima.t
		} : a;
		this.amostras.push(nova);
		const corte = nova.t - this.janelaMs - TRAJETORIA.duracaoMaxDeslocamentoMs;
		while (this.amostras.length > 2 && this.amostras[1].t < corte) this.amostras.shift();
	}
	/** Posição estimada da tocha no instante t. */
	posicaoEm(t) {
		const a = this.amostras;
		if (a.length === 0) return null;
		if (t <= a[0].t) return a[0];
		for (let k = a.length - 1; k > 0; k--) if (t >= a[k - 1].t) return posicaoEntre(a[k - 1], a[k], t);
		return a[0];
	}
	medir(agoraMs) {
		const a = this.amostras;
		if (a.length === 0) return PARADO;
		const t1 = Math.max(agoraMs, a[a.length - 1].t);
		const t0 = t1 - this.janelaMs;
		const quebras = [t0];
		for (let k = 1; k < a.length; k++) {
			const tIni = inicioDoDeslocamento(a[k - 1], a[k]);
			if (tIni > t0 && tIni < t1) quebras.push(tIni);
			if (a[k].t > t0 && a[k].t < t1) quebras.push(a[k].t);
		}
		quebras.push(t1);
		quebras.sort((p, q) => p - q);
		let caminho = 0;
		let anterior = this.posicaoEm(quebras[0]);
		for (let i = 1; i < quebras.length; i++) {
			const p = this.posicaoEm(quebras[i]);
			caminho += Math.hypot(p.x - anterior.x, p.y - anterior.y);
			anterior = p;
		}
		const inicio = this.posicaoEm(t0);
		const fim = this.posicaoEm(t1);
		const s = this.janelaMs / 1e3;
		return {
			avancoMms: (fim.x - inicio.x) / s,
			lateralMms: (fim.y - inicio.y) / s,
			totalMms: caminho / s
		};
	}
};
//#endregion
//#region src/modelo/simulacao.ts
/**
* H44: instabilidade do arco com estes ajustes, de −1 (curto demais) a 1
* (longo demais); zero dentro da tolerância do equilíbrio (H10).
*/
function instabilidadeArco(a, ctx) {
	const { desvio } = equilibrioArco(a, ctx);
	const excesso = Math.max(0, Math.abs(desvio) - EQUILIBRIO.tolerancia);
	return excesso === 0 ? 0 : Math.sign(desvio) * Math.min(1, excesso / 3);
}
/** Gravidade nos eixos da poça (H50), com o mesmo sentido de avanço de efeitoPosicao (H47). */
function gravidadePoca(g, sentido) {
	return {
		cabeca: Math.max(0, g.w),
		lado: g.n,
		descida: g.t * Math.sign(sentido)
	};
}
function sobreAPeca(x, y) {
	return x >= 0 && x <= PECA.comprimentoMm && Math.abs(y) <= PECA.larguraChapaMm;
}
/**
* Núcleo da simulação. Não conhece canvas, DOM nem mouse: recebe leituras
* { t, x, y } e devolve o estado. Por isso pode ser testada sem navegador.
*
* Ideia central: enquanto o arco está aberto, a tocha deposita metal a uma
* taxa constante no tempo, proporcional à alimentação do arame (H1). O metal
* cai onde a tocha está. Se ela anda devagar, o mesmo volume se acumula em
* menos comprimento → cordão mais largo. A tensão muda só a forma (H9).
*/
/** Cordão na forma da junta do contexto (H46). */
function novoCordao(ctx) {
	return new Cordao(void 0, void 0, void 0, {
		junta: juntaDe(ctx),
		dimensoes: {
			espessuraMm: ctx.espessuraMm,
			aberturaMm: ctx.aberturaMm
		}
	});
}
var Simulacao = class {
	contexto;
	cordao;
	/** Tudo o que é preciso para reproduzir a tentativa. */
	eventos = [];
	/** Tempo de arco por posição da junta (H20). */
	percurso = new Percurso();
	registro = [];
	ajustesAtuais = AJUSTES_PADRAO;
	estimador = new EstimadorVelocidade();
	ultima = null;
	arco = false;
	/** Até que instante o depósito já foi calculado. */
	tConsolidado = 0;
	tempoArcoMs = 0;
	aberturasDeArco = 0;
	encerrada = false;
	tempoPausadoMs = 0;
	inicioPausaMs = null;
	/** H49: congela o tempo de processo, inclusive o resfriamento. */
	pausar(agoraMs) {
		if (this.inicioPausaMs !== null) return;
		this.interromperArco();
		this.inicioPausaMs = agoraMs;
	}
	retomar(agoraMs) {
		if (this.inicioPausaMs === null) return;
		this.tempoPausadoMs += Math.max(0, agoraMs - this.inicioPausaMs);
		this.inicioPausaMs = null;
	}
	instanteDeProcesso(t) {
		return (this.inicioPausaMs ?? t) - this.tempoPausadoMs;
	}
	/** Aquecimento acumulado T (H32) e o instante a que ele se refere. */
	aquecimento = 0;
	tAquecimento = null;
	/** Posição da peça (H47): a atual e a última gravada nos eventos. */
	posicaoAtual;
	posicaoGravada;
	gravidadeAtual;
	constructor(contexto = CONTEXTO_PADRAO) {
		this.contexto = contexto;
		this.cordao = novoCordao(contexto);
		this.eventos.push({
			tipo: "ajustes",
			ajustes: this.ajustesAtuais
		});
		this.posicaoAtual = this.posicaoGravada = { ...contexto.posicaoInicial ?? POSICAO_PLANA };
		this.gravidadeAtual = gravidade(this.posicaoAtual);
	}
	get posicao() {
		return this.posicaoAtual;
	}
	/**
	* Tomba/gira a peça (H47). Recusado com o arco aberto (a peça não se mexe
	* durante o passe) ou com a peça presa na estrutura; devolve se aceitou.
	*/
	definirPosicao(p) {
		if (this.arco || this.contexto.posicaoFixa) return false;
		this.posicaoAtual = {
			rolagemGraus: p.rolagemGraus,
			giroGraus: p.giroGraus
		};
		this.gravidadeAtual = gravidade(this.posicaoAtual);
		return true;
	}
	get arcoAberto() {
		return this.arco;
	}
	get ajustes() {
		return this.ajustesAtuais;
	}
	get tentativaEncerrada() {
		return this.encerrada;
	}
	/** Tempo total com o arco aberto (ms), consolidado. */
	get tempoDeArcoMs() {
		return this.tempoArcoMs;
	}
	/** Muda tensão/alimentação. Recusado com o arco aberto (H12); devolve se aceitou. */
	definirAjustes(a) {
		if (this.arco) return false;
		this.ajustesAtuais = limitarAjustes(a);
		this.eventos.push({
			tipo: "ajustes",
			ajustes: this.ajustesAtuais
		});
		return true;
	}
	/** Nova leitura de posição (com ou sem arco). */
	moverTocha(a) {
		if (this.inicioPausaMs !== null) return;
		a = {
			...a,
			t: this.instanteDeProcesso(a.t)
		};
		if (this.arco && this.ultima) this.integrarAte(a);
		this.ultima = a;
		this.estimador.adicionar(a);
		if (this.arco) {
			this.registrar(a);
			this.eventos.push({
				tipo: "mover",
				t: a.t,
				x: a.x,
				y: a.y
			});
		}
	}
	iniciarArco(a) {
		if (this.inicioPausaMs !== null) return;
		if (this.arco || this.encerrada) {
			this.moverTocha(a);
			return;
		}
		this.moverTocha(a);
		a = {
			...a,
			t: this.instanteDeProcesso(a.t)
		};
		const p = this.posicaoAtual;
		if (p.rolagemGraus !== this.posicaoGravada.rolagemGraus || p.giroGraus !== this.posicaoGravada.giroGraus) {
			this.eventos.push({
				tipo: "posicao",
				rolagemGraus: p.rolagemGraus,
				giroGraus: p.giroGraus
			});
			this.posicaoGravada = p;
		}
		this.arco = true;
		this.aberturasDeArco++;
		this.tConsolidado = a.t;
		this.esfriarAte(a.t);
		this.registrar(a);
		this.eventos.push({
			tipo: "inicio",
			t: a.t,
			x: a.x,
			y: a.y
		});
	}
	encerrarArco(a) {
		if (!this.arco) return;
		this.moverTocha(a);
		a = {
			...a,
			t: this.instanteDeProcesso(a.t)
		};
		this.eventos.push({
			tipo: "fim",
			t: a.t,
			x: a.x,
			y: a.y
		});
		this.arco = false;
	}
	/**
	* Fecha o arco SEM consolidar o tempo que passou desde a última leitura
	* consolidada (H49): pausa, perda de foco ou janela escondida. Fechar com
	* encerrarArco(agora) depositaria, de uma vez, todo o tempo parado da
	* pausa como se a tocha tivesse ficado ali soldando.
	*/
	interromperArco() {
		if (!this.arco || !this.ultima) return;
		const p = this.ultima;
		this.encerrarArco({
			t: Math.max(this.tConsolidado, p.t) + this.tempoPausadoMs,
			x: p.x,
			y: p.y
		});
	}
	/**
	* Chamado a cada quadro com o relógio atual. Se o mouse não mandou leituras,
	* a tocha está parada e continua depositando no mesmo lugar.
	*
	* Só consolidamos até (agora − duração máxima de deslocamento): uma leitura
	* que ainda vai chegar não pode mudar o que já foi calculado. Assim o
	* resultado é o mesmo com qualquer taxa de quadros.
	*/
	avancarTempo(agoraMs) {
		if (!this.arco || !this.ultima) return;
		if (this.inicioPausaMs !== null) return;
		const limite = this.instanteDeProcesso(agoraMs) - TRAJETORIA.duracaoMaxDeslocamentoMs;
		if (limite > this.tConsolidado) {
			this.depositarParado(this.ultima, this.tConsolidado, limite);
			this.tConsolidado = limite;
		}
	}
	estado(agoraMs) {
		const p = this.ultima;
		return {
			arcoAberto: this.arco,
			tentativaEncerrada: this.encerrada,
			ajustes: this.ajustesAtuais,
			posicao: p ? {
				x: p.x,
				y: p.y
			} : null,
			sobreAPeca: p ? sobreAPeca(p.x, p.y) : false,
			velocidades: this.estimador.medir(this.instanteDeProcesso(agoraMs)),
			tempoArcoMs: this.tempoArcoMs,
			aquecimento: this.aquecimento
		};
	}
	/**
	* Encerra e avalia a tentativa (H19). Só com o arco fechado; devolve null
	* se o arco estiver aberto. Depois disso, nada mais é depositado até
	* reiniciar().
	*/
	finalizar() {
		if (this.arco) return null;
		this.encerrada = true;
		const ajustesUsados = [];
		for (const p of this.registro) {
			const ultimo = ajustesUsados[ajustesUsados.length - 1];
			if (!ultimo || ultimo.alimentacao !== p.ajustes.alimentacao || ultimo.tensao !== p.ajustes.tensao) ajustesUsados.push(p.ajustes);
		}
		const avaliacao = avaliar(this.cordao);
		return {
			avaliacao,
			contexto: this.contexto,
			movimento: analisarMovimento(this.percurso, avaliacao),
			ajustesUsados,
			tempoArcoMs: this.tempoArcoMs,
			aberturasDeArco: this.aberturasDeArco
		};
	}
	/** Nova tentativa: chapa limpa. A posição da tocha e os ajustes são mantidos. */
	reiniciar() {
		this.cordao = novoCordao(this.contexto);
		this.percurso = new Percurso();
		this.registro = [];
		this.eventos = [{
			tipo: "ajustes",
			ajustes: this.ajustesAtuais
		}];
		this.posicaoGravada = { ...this.contexto.posicaoInicial ?? POSICAO_PLANA };
		this.aquecimento = 0;
		this.tAquecimento = null;
		this.arco = false;
		this.encerrada = false;
		this.aberturasDeArco = 0;
		this.tempoArcoMs = 0;
		this.estimador.limpar();
		if (this.ultima) this.estimador.adicionar(this.ultima);
	}
	integrarAte(a1) {
		const a0 = this.ultima;
		const tMov = Math.max(inicioDoDeslocamento(a0, a1), this.tConsolidado);
		if (tMov > this.tConsolidado) this.depositarParado(a0, this.tConsolidado, tMov);
		if (a1.t > tMov) this.depositarTrecho(a0, a1, tMov, a1.t);
		this.tConsolidado = Math.max(this.tConsolidado, a1.t);
	}
	/** Com o arco fechado a peça só esfria (H32). */
	esfriarAte(t) {
		if (this.tAquecimento === null) {
			this.tAquecimento = t;
			return;
		}
		if (t <= this.tAquecimento) return;
		const tau = MATERIAIS[this.contexto.material].tauAquecimentoS;
		this.aquecimento *= Math.exp(-(t - this.tAquecimento) / 1e3 / tau);
		this.tAquecimento = t;
	}
	/**
	* Avança o aquecimento de t0 a t1 com potência constante, de forma EXATA
	* (H32), e devolve ∫(1 + e·T) dt em segundos. Como a solução é exata,
	* dividir o intervalo em pedaços diferentes dá o mesmo resultado.
	*/
	aquecer(t0, t1, potencia) {
		this.esfriarAte(t0);
		const m = MATERIAIS[this.contexto.material];
		const dt = (t1 - t0) / 1e3;
		const final = m.ganhoAquecimento * potencia;
		const decaimento = Math.exp(-dt / m.tauAquecimentoS);
		const integralT = final * dt + (this.aquecimento - final) * m.tauAquecimentoS * (1 - decaimento);
		this.aquecimento = final + (this.aquecimento - final) * decaimento;
		this.tAquecimento = t1;
		return dt + m.efeitoAquecimento * integralT;
	}
	depositarParado(p, t0, t1) {
		this.tempoArcoMs += t1 - t0;
		if (!sobreAPeca(p.x, p.y)) {
			this.esfriarAte(t1);
			return;
		}
		const potencia = potenciaRelativa(this.ajustesAtuais, this.contexto);
		const integral = this.aquecer(t0, t1, potencia);
		const volume = taxaDeposicao(this.ajustesAtuais, this.contexto) * (t1 - t0) / 1e3;
		const ef = efeitoPosicao(this.gravidadeAtual, 0);
		this.cordao.depositar(p.x, p.y + ef.desvioMm, volume, t1, razaoEfetiva(this.ajustesAtuais, this.contexto) * ef.razao, espalhamentoDoMovimento(this.contexto), instabilidadeArco(this.ajustesAtuais, this.contexto), gravidadePoca(this.gravidadeAtual, 0));
		this.percurso.registrar(p.x, p.y, t1 - t0, potencia * (t1 - t0) / 1e3, potencia * integral * ef.fusao);
	}
	/** Divide o trecho em pedaços curtos e deposita um pouco em cada um. */
	depositarTrecho(p0, p1, t0, t1) {
		this.tempoArcoMs += t1 - t0;
		const n = Math.max(1, Math.ceil(Math.hypot(p1.x - p0.x, p1.y - p0.y) / MODELO.subdivisaoMaxMm));
		const dt = (t1 - t0) / n;
		const volume = taxaDeposicao(this.ajustesAtuais, this.contexto) * dt / 1e3;
		const ef = efeitoPosicao(this.gravidadeAtual, p1.x - p0.x);
		const razao = razaoEfetiva(this.ajustesAtuais, this.contexto) * ef.razao;
		const potencia = potenciaRelativa(this.ajustesAtuais, this.contexto);
		const sigma = espalhamentoDoMovimento(this.contexto);
		const instab = instabilidadeArco(this.ajustesAtuais, this.contexto);
		const gp = gravidadePoca(this.gravidadeAtual, p1.x - p0.x);
		for (let j = 0; j < n; j++) {
			const f = (j + .5) / n;
			const x = p0.x + (p1.x - p0.x) * f;
			const y = p0.y + (p1.y - p0.y) * f;
			if (!sobreAPeca(x, y)) {
				this.esfriarAte(t0 + (j + 1) * dt);
				continue;
			}
			const integral = this.aquecer(t0 + j * dt, t0 + (j + 1) * dt, potencia);
			this.cordao.depositar(x, y + ef.desvioMm, volume, t0 + (j + 1) * dt, razao, sigma, instab, gp);
			this.percurso.registrar(x, y, dt, potencia * dt / 1e3, potencia * integral * ef.fusao);
		}
	}
	registrar(a) {
		this.registro.push({
			t: a.t,
			x: a.x,
			y: a.y,
			tempoArcoMs: this.tempoArcoMs,
			ajustes: this.ajustesAtuais
		});
	}
};
//#endregion
//#region src/modelo/replay.ts
/**
* Reproduz uma tentativa a partir do registro de eventos. Como a simulação
* não depende dos quadros, o cordão reproduzido é igual ao original — é isso
* que permite ao professor inspecionar a solda sem depender de uma captura
* de tela.
*/
function reproduzir(contexto, eventos) {
	const sim = new Simulacao(contexto);
	for (const e of eventos) if (e.tipo === "ajustes") sim.definirAjustes(e.ajustes);
	else if (e.tipo === "posicao") sim.definirPosicao(e);
	else if (e.tipo === "inicio") sim.iniciarArco(e);
	else if (e.tipo === "mover") sim.moverTocha(e);
	else sim.encerrarArco(e);
	return sim;
}
//#endregion
//#region src/pontuacao/oficial.ts
/**
* Pontuação OFICIAL: reproduz a tentativa a partir do registro salvo e só
* então pontua. Assim a nota, o replay do professor e a inspeção usam
* exatamente os mesmos dados.
*/
function pontuarRegistro(missao, dificuldade, contexto, eventos, pesos = PESOS_PADRAO) {
	const sim = reproduzir(contexto, descompactar(eventos));
	return {
		sim,
		resultado: pontuar({
			missao,
			dificuldade,
			contexto,
			cordao: sim.cordao,
			percurso: sim.percurso,
			tempoArcoMs: sim.tempoDeArcoMs,
			aberturasDeArco: sim.eventos.filter((ev) => ev.tipo === "inicio").length,
			eventos: sim.eventos
		}, pesos)
	};
}
//#endregion
//#region servidor/avaliar.ts
function conferirRegistro(dados, limiteMs, decorridoMs) {
	if (!eventosValidos(dados) || !Number.isFinite(dados.t0) || dados.lista.length < 2 || dados.lista.length > 16e3) throw new Error("Registro de soldagem inválido ou grande demais.");
	let anterior = -1, aberto = false, aberturas = 0, distancia = 0, ultimo = null;
	for (const e of dados.lista) if (e[0] === "a") {
		if (e[1] < 1 || e[1] > 10 || e[2] < 1 || e[2] > 10) throw new Error("Regulagem fora da faixa da máquina.");
	} else if (e[0] === "p") {
		if (aberto || e[1] < 0 || e[1] > 180 || Math.abs(e[2]) > 360) throw new Error("Posição da peça inválida.");
	} else {
		const [tipo, t, x, y] = e;
		if (t < 0 || t < anterior || t > limiteMs + 100 || t > decorridoMs + 1500 || Math.abs(x) > 2e3 || Math.abs(y) > 2e3) throw new Error("Trajetória ou tempo incompatível com a partida.");
		if (tipo === "i") {
			if (aberto) throw new Error("Arco aberto duas vezes.");
			aberto = true;
			aberturas++;
		} else if (!aberto) throw new Error("Trajetória sem arco aberto.");
		if (ultimo) distancia += Math.hypot(x - ultimo.x, y - ultimo.y);
		if (distancia > 5e4) throw new Error("Trajetória excessiva.");
		if (tipo === "f") aberto = false;
		anterior = t;
		ultimo = {
			x,
			y
		};
	}
	if (aberto || !aberturas || anterior <= 0) throw new Error("Feche o arco antes de entregar a tentativa.");
	return {
		versao: 1,
		t0: 0,
		lista: dados.lista.map((e) => [...e])
	};
}
function avaliarRegistroRede(config, dados, limiteMs, decorridoMs) {
	const eventos = conferirRegistro(dados, limiteMs, decorridoMs), c = configuracaoRede(config);
	const { resultado } = pontuarRegistro(c.missao, config.dificuldade, c.contexto, eventos);
	if (!Number.isFinite(resultado.total) || resultado.total < 0 || resultado.total > 1e3) throw new Error("O registro não produziu uma nota válida.");
	return {
		eventos,
		resultado
	};
}
//#endregion
//#region servidor/salas.ts
var randomBytes = (n) => globalThis.crypto.getRandomValues(new Uint8Array(n));
var randomUUID = () => globalThis.crypto.randomUUID();
var ErroSala = class extends Error {
	status;
	constructor(mensagem, status = 400) {
		super(mensagem);
		this.status = status;
	}
};
var Salas = class {
	agora;
	tempos;
	salas = /* @__PURE__ */ new Map();
	constructor(agora = () => Date.now(), tempos = {
		contagem: 5e3,
		partida: 18e4,
		queda: 3e4,
		expiracao: 18e5
	}) {
		this.agora = agora;
		this.tempos = tempos;
	}
	nome(d) {
		if (typeof d !== "string" || !d.trim() || d.trim().length > 24 || /[\x00-\x1f]/.test(d)) throw new ErroSala("Use um apelido de 1 a 24 caracteres.");
		return d.trim();
	}
	novoJogador(nome, anfitriao) {
		return {
			id: randomUUID(),
			nome: this.nome(nome),
			anfitriao,
			conectado: false,
			desconectadoEm: this.agora(),
			estado: "preparando",
			revanche: false,
			entrega: null,
			token: Array.from(randomBytes(32), (v) => v.toString(16).padStart(2, "0")).join("")
		};
	}
	credencial(s, j) {
		return {
			codigo: s.codigo,
			jogadorId: j.id,
			token: j.token,
			protocolo: PROTOCOLO_REDE
		};
	}
	obter(codigo) {
		const s = this.salas.get(codigo.toUpperCase());
		if (!s) throw new ErroSala("Sala não encontrada ou expirada.", 404);
		return s;
	}
	autenticar(s, token) {
		const j = s.jogadores.find((j) => j.token === token);
		if (!j) throw new ErroSala("Acesso à sala não autorizado.", 403);
		return j;
	}
	criar(nome, config, protocolo) {
		this.compativel(protocolo);
		if (this.salas.size >= 64) throw new ErroSala("O servidor está com muitas salas. Tente depois.", 503);
		try {
			configuracaoRede(config);
		} catch (e) {
			throw new ErroSala(e.message);
		}
		const j = this.novoJogador(nome, true), alfabeto = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
		let codigo = "";
		do
			codigo = [...randomBytes(6)].map((v) => alfabeto[v % 32]).join("");
		while (this.salas.has(codigo));
		const s = {
			codigo,
			config: {
				processo: "mig",
				missaoId: config.missaoId,
				dificuldade: config.dificuldade
			},
			fase: "espera",
			rodada: 1,
			jogadores: [j],
			criadaEm: this.agora(),
			inicioEm: null,
			fimEm: null,
			motivo: "",
			vencedorId: null
		};
		this.salas.set(codigo, s);
		return this.credencial(s, j);
	}
	entrar(codigo, nome, protocolo) {
		this.compativel(protocolo);
		const s = this.obter(codigo);
		if (s.fase !== "espera" || s.jogadores.length >= 2) throw new ErroSala("Esta sala já está completa ou em partida.", 409);
		const j = this.novoJogador(nome, false);
		s.jogadores.push(j);
		return this.credencial(s, j);
	}
	compativel(p) {
		if (p !== "soldagem-rede-1.7.1") throw new ErroSala("Versão de rede diferente. Recarregue o jogo pelo endereço do servidor.", 409);
	}
	conectar(codigo, token, conectado) {
		const s = this.obter(codigo), j = this.autenticar(s, token);
		j.conectado = conectado;
		j.desconectadoEm = conectado ? null : this.agora();
		if (s.fase === "espera" && s.jogadores.length === 2 && s.jogadores.every((x) => x.estado === "pronto" && x.conectado)) this.contar(s);
	}
	estado(codigo, token) {
		const s = this.obter(codigo), eu = this.autenticar(s, token);
		return {
			codigo: s.codigo,
			config: { ...s.config },
			fase: s.fase,
			rodada: s.rodada,
			protocolo: PROTOCOLO_REDE,
			modelo: MODELO_REDE,
			agora: this.agora(),
			inicioEm: s.inicioEm,
			fimEm: s.fimEm,
			motivo: s.motivo,
			vencedorId: s.vencedorId,
			jogadores: s.jogadores.map((j) => ({
				id: j.id,
				nome: j.nome,
				anfitriao: j.anfitriao,
				conectado: j.conectado,
				estado: j.estado,
				revanche: j.revanche,
				entrega: s.fase === "resultado" || j === eu ? j.entrega : null
			}))
		};
	}
	comando(codigo, token, dados) {
		const s = this.obter(codigo), j = this.autenticar(s, token);
		if (!dados || typeof dados !== "object") throw new ErroSala("Comando inválido.");
		if (dados.tipo === "sair") {
			if (s.fase === "espera" && !j.anfitriao) {
				s.jogadores = s.jogadores.filter((x) => x !== j);
				s.jogadores.forEach((x) => x.estado = "preparando");
				return;
			}
			j.estado = "abandonou";
			j.conectado = false;
			if (s.fase === "espera" || s.fase === "contagem") {
				s.fase = "encerrada";
				s.motivo = `${j.nome} saiu da sala.`;
			} else if (s.fase === "partida") this.finalizar(s, `${j.nome} abandonou a disputa.`, s.jogadores.find((x) => x !== j)?.id ?? null);
			return;
		}
		if (dados.rodada !== s.rodada) throw new ErroSala("Esta mensagem pertence a outra rodada.", 409);
		if (dados.tipo === "pronto") {
			if (s.fase !== "espera" || typeof dados.pronto !== "boolean") throw new ErroSala("Não é possível mudar a prontidão agora.", 409);
			j.estado = dados.pronto ? "pronto" : "preparando";
			if (s.jogadores.length === 2 && s.jogadores.every((x) => x.estado === "pronto" && x.conectado)) this.contar(s);
		} else if (dados.tipo === "entregar") {
			if (j.entrega) return;
			if (s.fase !== "partida" || !s.inicioEm || this.agora() < s.inicioEm || this.agora() > (s.fimEm ?? 0) + 5e3 || j.estado === "abandonou") throw new ErroSala("A partida não está recebendo entregas.", 409);
			try {
				j.entrega = avaliarRegistroRede(s.config, dados.eventos, this.tempos.partida, this.agora() - s.inicioEm);
			} catch (e) {
				throw new ErroSala(e.message);
			}
			j.estado = "entregou";
			if (s.jogadores.every((x) => x.entrega)) this.finalizar(s, "As duas soldas foram avaliadas pelo servidor.");
		} else if (dados.tipo === "revanche") {
			if (s.fase !== "resultado" || s.jogadores.some((x) => x.estado === "abandonou" || !x.conectado)) throw new ErroSala("A revanche precisa dos dois jogadores conectados.", 409);
			j.revanche = true;
			if (s.jogadores.every((x) => x.revanche)) {
				s.rodada++;
				s.vencedorId = null;
				s.motivo = "";
				for (const x of s.jogadores) {
					x.entrega = null;
					x.revanche = false;
					x.estado = "pronto";
				}
				this.contar(s);
			}
		} else throw new ErroSala("Comando desconhecido.");
	}
	contar(s) {
		s.fase = "contagem";
		s.inicioEm = this.agora() + this.tempos.contagem;
		s.fimEm = s.inicioEm + this.tempos.partida;
	}
	finalizar(s, motivo, vencedor) {
		s.fase = "resultado";
		s.motivo = motivo;
		if (vencedor !== void 0) {
			s.vencedorId = vencedor;
			return;
		}
		const [a, b] = s.jogadores;
		if (!!a?.entrega !== !!b?.entrega) {
			s.vencedorId = a?.entrega ? a.id : b.id;
			return;
		}
		const pa = a?.entrega?.resultado.total ?? 0, pb = b?.entrega?.resultado.total ?? 0;
		s.vencedorId = pa === pb ? null : pa > pb ? a.id : b.id;
	}
	atualizar() {
		const agora = this.agora();
		for (const [codigo, s] of this.salas) {
			if (agora - s.criadaEm > this.tempos.expiracao) {
				this.salas.delete(codigo);
				continue;
			}
			if (s.fase === "contagem" && agora >= (s.inicioEm ?? Infinity)) {
				s.fase = "partida";
				s.jogadores.forEach((j) => j.estado = "soldando");
			}
			if (s.fase === "partida" && agora > (s.fimEm ?? Infinity) + 5e3) {
				for (const j of s.jogadores) if (!j.entrega) j.estado = "tempo-esgotado";
				this.finalizar(s, "Prazo encerrado. Tentativas sem entrega valem zero.");
			}
			if (s.fase === "partida" && s.jogadores.every((j) => !j.conectado && j.desconectadoEm !== null && agora - j.desconectadoEm > this.tempos.queda)) {
				s.fase = "encerrada";
				s.motivo = "Os dois jogadores perderam a conexão.";
			}
			for (const j of [...s.jogadores]) if (j.desconectadoEm !== null && agora - j.desconectadoEm > this.tempos.queda && !j.conectado && !["resultado", "encerrada"].includes(s.fase)) this.comando(codigo, j.token, { tipo: "sair" });
		}
	}
	codigos() {
		return [...this.salas.keys()];
	}
	guardar(codigo) {
		return JSON.stringify({
			protocolo: PROTOCOLO_REDE,
			sala: this.obter(codigo)
		});
	}
	restaurar(dados) {
		const registro = JSON.parse(dados);
		if (registro.protocolo !== "soldagem-rede-1.7.1") throw new ErroSala("Esta sala usa outra versão. Crie uma nova sala.", 409);
		this.salas.set(registro.sala.codigo, registro.sala);
	}
	pulso(codigo, token) {
		const s = this.obter(codigo);
		this.autenticar(s, token);
		for (const j of s.jogadores) if (j.conectado && j.ultimoPulso !== void 0 && this.agora() - j.ultimoPulso > 1e4) {
			j.conectado = false;
			j.desconectadoEm = j.ultimoPulso;
		}
		this.atualizar();
		const j = this.autenticar(this.obter(codigo), token);
		if (j.estado === "abandonou") return;
		j.ultimoPulso = this.agora();
		this.conectar(codigo, token, true);
	}
};
//#endregion
//#region servidor/http.mjs
function lerJson(req) {
	return new Promise((aceitar, rejeitar) => {
		let tamanho = 0, excesso = false;
		const partes = [];
		req.on("data", (b) => {
			if (excesso) return;
			tamanho += b.length;
			if (tamanho > 1048576) {
				excesso = true;
				partes.length = 0;
				rejeitar(new ErroSala("Mensagem grande demais.", 413));
			} else partes.push(b);
		});
		req.on("end", () => {
			if (excesso) return;
			try {
				const o = JSON.parse(Buffer.concat(partes).toString("utf8"));
				if (!o || typeof o !== "object" || Array.isArray(o)) throw Error();
				aceitar(o);
			} catch {
				rejeitar(new ErroSala("Mensagem JSON inválida."));
			}
		});
		req.on("error", rejeitar);
	});
}
var mime = {
	".html": "text/html; charset=utf-8",
	".js": "text/javascript; charset=utf-8",
	".css": "text/css; charset=utf-8",
	".png": "image/png",
	".svg": "image/svg+xml",
	".ico": "image/x-icon",
	".woff2": "font/woff2",
	".ttf": "font/ttf"
};
function criarServidor(op) {
	const salas = op.salas ?? new Salas(), publico = resolve(op.publico);
	const fluxos = /* @__PURE__ */ new Set();
	const taxa = /* @__PURE__ */ new Map();
	const json = (res, status, dado) => {
		res.writeHead(status, {
			"Content-Type": "application/json; charset=utf-8",
			"Cache-Control": "no-store",
			"X-Content-Type-Options": "nosniff"
		});
		res.end(JSON.stringify(dado));
	};
	const publicar = () => {
		salas.atualizar();
		for (const f of fluxos) try {
			if (f.res.writableLength > 1048576) {
				f.res.destroy();
				continue;
			}
			f.res.write(`data: ${JSON.stringify(salas.estado(f.codigo, f.token))}\n\n`);
		} catch {
			f.res.write(`event: erro\ndata: ${JSON.stringify({ erro: "Sala encerrada ou expirada." })}\n\n`);
			f.res.end();
			fluxos.delete(f);
		}
	};
	const servidor = createServer(async (req, res) => {
		try {
			const p = new URL(req.url ?? "/", "http://servidor").pathname;
			if (p.startsWith("/api/")) {
				const origem = req.headers.origin;
				if (origem && new URL(origem).host !== req.headers.host && !op.origens?.includes(origem)) throw new ErroSala("Origem não permitida.", 403);
				const ip = req.socket.remoteAddress ?? "local", agora = Date.now(), anterior = taxa.get(ip);
				if (!anterior || agora - anterior.inicio > 6e4) taxa.set(ip, {
					inicio: agora,
					n: 1
				});
				else if (++anterior.n > 120) throw new ErroSala("Muitas solicitações. Aguarde um minuto.", 429);
				salas.atualizar();
				if (p === "/api/rede/info" && req.method === "GET") {
					json(res, 200, {
						protocolo: PROTOCOLO_REDE,
						modelo: MODELO_REDE,
						versao: "1.8",
						processos: ["mig"],
						enderecos: enderecos(req.socket.localPort ?? 5197)
					});
					return;
				}
				if (p === "/api/salas" && req.method === "POST") {
					const d = await lerJson(req);
					json(res, 201, salas.criar(d.nome, d.config, d.protocolo));
					publicar();
					return;
				}
				const m = p.match(/^\/api\/salas\/([A-Z2-9]{6})\/(entrar|eventos|comandos|estado)$/i);
				if (!m) throw new ErroSala("Rota de rede não encontrada.", 404);
				const codigo = m[1].toUpperCase(), acao = m[2], token = req.headers.authorization?.replace(/^Bearer /, "") ?? "";
				if (acao === "entrar" && req.method === "POST") {
					const d = await lerJson(req);
					json(res, 200, salas.entrar(codigo, d.nome, d.protocolo));
					publicar();
					return;
				}
				if (acao === "eventos" && req.method === "GET") {
					salas.estado(codigo, token);
					for (const f of fluxos) if (f.codigo === codigo && f.token === token) {
						fluxos.delete(f);
						f.res.end();
					}
					salas.conectar(codigo, token, true);
					res.writeHead(200, {
						"Content-Type": "text/event-stream; charset=utf-8",
						"Cache-Control": "no-cache, no-transform",
						"Connection": "keep-alive",
						"X-Accel-Buffering": "no"
					});
					res.write(": conectado\n\n");
					const f = {
						codigo,
						token,
						res
					};
					fluxos.add(f);
					publicar();
					res.on("close", () => {
						if (fluxos.delete(f)) {
							try {
								salas.conectar(codigo, token, false);
							} catch {}
							publicar();
						}
					});
					return;
				}
				if (acao === "estado" && req.method === "GET") {
					json(res, 200, salas.estado(codigo, token));
					return;
				}
				if (acao === "comandos" && req.method === "POST") {
					const d = await lerJson(req);
					salas.comando(codigo, token, d);
					json(res, 200, salas.estado(codigo, token));
					publicar();
					return;
				}
				throw new ErroSala("Método não permitido.", 405);
			}
			if (req.method !== "GET" && req.method !== "HEAD") {
				res.writeHead(405);
				res.end();
				return;
			}
			const arquivo = resolve(publico, "." + decodeURIComponent(p === "/" ? "/index.html" : p));
			if (!arquivo.startsWith(publico + sep)) throw new ErroSala("Arquivo não encontrado.", 404);
			if (!(await stat(arquivo).catch(() => null))?.isFile()) throw new ErroSala("Arquivo não encontrado.", 404);
			const dados = await readFile(arquivo);
			res.writeHead(200, {
				"Content-Type": mime[extname(arquivo)] ?? "application/octet-stream",
				"Cache-Control": "no-cache",
				"X-Content-Type-Options": "nosniff",
				"Referrer-Policy": "same-origin"
			});
			res.end(req.method === "HEAD" ? void 0 : dados);
		} catch (e) {
			if (!res.headersSent) json(res, e instanceof ErroSala ? e.status : 500, { erro: e instanceof ErroSala ? e.message : "O servidor não conseguiu concluir esta ação." });
			else res.end();
		}
	});
	servidor.requestTimeout = 15e3;
	servidor.headersTimeout = 15e3;
	const timer = setInterval(() => {
		publicar();
		const agora = Date.now();
		for (const [ip, v] of taxa) if (agora - v.inicio > 6e4) taxa.delete(ip);
	}, 1e3);
	timer.unref();
	servidor.on("close", () => {
		clearInterval(timer);
		for (const f of fluxos) f.res.end();
		fluxos.clear();
	});
	return {
		servidor,
		salas,
		publicar,
		fechar: () => {
			for (const f of fluxos) f.res.end();
			return new Promise((ok) => servidor.close(() => ok()));
		}
	};
}
function enderecos(porta) {
	const ips = /* @__PURE__ */ new Set();
	for (const interfaces of Object.values(networkInterfaces())) for (const i of interfaces ?? []) if (i.family === "IPv4" && !i.internal) ips.add(`http://${i.address}:${porta}/`);
	const locais = [...ips].sort((a, b) => Number(/^http:\/\/(?:192\.168\.|10\.|172\.(?:1[6-9]|2\d|3[01])\.)/.test(b)) - Number(/^http:\/\/(?:192\.168\.|10\.|172\.(?:1[6-9]|2\d|3[01])\.)/.test(a)));
	return [`http://localhost:${porta}/`, ...locais];
}
//#endregion
//#region servidor/index.mjs
var porta = Number(process.env.PORT ?? 5197);
var host = process.env.HOST ?? "0.0.0.0";
if (!Number.isInteger(porta) || porta < 1 || porta > 65535) throw new Error("PORT deve ser uma porta entre 1 e 65535.");
var app = criarServidor({
	publico: process.env.PUBLIC_DIR ?? resolve(dirname(fileURLToPath(import.meta.url)), "../dist"),
	origens: process.env.ORIGENS_PERMITIDAS?.split(",").filter(Boolean)
});
app.servidor.on("error", (erro) => {
	console.error("Não foi possível iniciar o servidor:", erro.message);
	process.exitCode = 1;
});
app.servidor.listen(porta, host, () => {
	console.log("\nOFICINA DE SOLDAGEM v1.8 — X1 EM REDE\n");
	console.log("Mantenha esta janela aberta. Nos dois PCs, abra um dos endereços abaixo no navegador:");
	for (const url of enderecos(porta)) console.log("  " + url);
	if (process.env.ABRIR_NAVEGADOR === "1" && process.platform === "win32") {
		const navegador = spawn("rundll32.exe", ["url.dll,FileProtocolHandler", `http://localhost:${porta}/?rede=1`], {
			windowsHide: true,
			detached: true,
			stdio: "ignore"
		});
		navegador.on("error", () => console.log("Abra o endereço acima no seu navegador."));
		navegador.unref();
	}
	console.log("\nArcade → X1 em rede → Criar sala / Entrar por código.");
	console.log("No segundo PC, use o endereço com o IP do anfitrião; localhost só funciona neste PC.\nCtrl+C encerra o servidor e as salas.\n");
});
//#endregion
export {};
